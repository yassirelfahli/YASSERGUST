#This file produces curves of the upper bound and GMDC of the measures of 
# mean-dependence using both the Gaussian, DL, ESC6, and the MMD kernels.
rm(list = ls()) #clear memory
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#load packages
library(estrpac)
library(MASS)
library(pbapply)
#================================================================================>
#Set parameters
pmax=30
#================================================================================>
#compute the variance of the ESC6 kernel using simulation
fnsimESC6=function(pz){
  n=250; R=500; Kern_array = array(NA,dim = c(n,n,R))
  for(l in 1:R){
    set.seed(l)
    Z=mvrnorm(n=n,mu=rep(0,pz),Sigma = diag(pz))
    Kern_array[,,l]=Kern.fun_Esc6(Z)
  }
  sdMat = matrix(0,n,n)
  for(i in 1:n){
    for (j in 1:i) {
      if(i!=j){
        sdMat[i,j] = sd(c(Kern_array[i,j,]))
        sdMat[j,i]=sdMat[i,j]
      }#ensure zeroes on diagonal
    }
  }
  mean((c(sdMat)))
}
fnsimESC6=Vectorize(fnsimESC6)
#illustration
system.time((tsE=fnsimESC6(pz=8)))

vsdESC6 = pbsapply(1:pmax,fnsimESC6,cl=4) #elapsed=02h 22m 40s
spline.ESC=spline(1:pmax,vsdESC6)
plot(spline.ESC$x,spline.ESC$y,type = "l")

mESC6 <- lm(vsdESC6 ~ poly(1:pmax,6))
par(mfrow=c(1,2))
plot(1:pmax,vsdESC6,type = "l")
plot(1:pmax,mESC6$fitted.values,type = "l")
par(mfrow=c(1,1))
#================================================================================>

fMMD = function(p) sqrt(2*p-4*(gamma((p+1)/2)/gamma(p/2))^2)
fGauss=function(p) sqrt(5^(-p/2) - 3^(-p))
fDL = function(p) sqrt(2^(-p) - (2/3)^(2*p))

pdf("Fig_Kernel_Var.pdf")
curve(fMMD,1,pmax,ylim=c(-0.1,1.1),xlab = latex2exp::TeX("$p_z$"),ylab = "")
curve(fGauss,1,pmax,add = T,lty=2,col="blue")
curve(fDL,1,pmax,add = T,lty=3,col="darkgreen")
lines(1:pmax,mESC6$fitted.values,lty = 4,col=4) #generated below
abline(h=0,lty=4,col="red") #the zero lower bound on variance
legend(pmax-10,0.8,c("MMD","Gauss","DL","ESC6"),lty = c(1,2,3,4),col = c(1,2,3,4))
dev.off()

#---------------------------------------------------->
#illustration with pz=18 instruments
round(fGauss(18),5)
round(fMMD(18),2)
#---------------------------------------------------->


#---------------------------------------------------->
GMDC=function(U,Z,Kern="Euclid"){
  Ker=estrpac::Kern.fun(Z,Kern = Kern)
  U=U-mean(U); n=length(U)
  GMDD = t(U)%*%Ker%*%U/(n^2)
  Ukh = apply(Ker, 1, sum)/n
  var.U=var(U)
  Ker2=Ker; vk = apply(Ker,2,mean)
  for (i in 1:n) {
    Ker2[i,] = Ker2[i,] - vk
    Ker2[,i] = Ker2[,i] - vk
  }
  Ker2=Ker2+mean(c(Ker))
  dvar.Z=mean(c(Ker2)^2)
  GMDC=GMDD/sqrt(var.U*dvar.Z)
  list(GMDC=GMDC,GMDD=GMDD,var.U=var.U,dvar.Z=dvar.Z,Kern=Kern)
}

# e.g.,
n=1000
Z=rnorm(n)
U = Z+(rchisq(n,1)-1)/sqrt(2)
#test GMDC function
GMDC(U,Z,"Euclid")
GMDC(U,Z,"Gauss")
GMDC(U,Z,"DL")
GMDC(U,Z,"Esc6")

#Now compute GMDC as a function of pz and provide the plot for all the kernels
GMDCvecfn=function(pzmax){
  n=2500
  set.seed(n);Zmat = mvrnorm(n,rep(0,pzmax+1),diag(pzmax+1))
  V=Zmat[,1]; Zmat=Zmat[,-1]
  fn=function(j){
   Z=as.matrix(Zmat[,1:j])
   U=(apply(Z, 1, sum)/sqrt(j)+V)/sqrt(2)
   c(GMDC(U,Z,"Euclid")$GMDC,GMDC(U,Z,"Gauss")$GMDC,GMDC(U,Z,"DL")$GMDC,GMDC(U,Z,"Esc6")$GMDC)
  };fn=Vectorize(fn)
  pbapply::pbsapply(1:pzmax, fn,cl=4)
}

GMDCmat = GMDCvecfn(pzmax = pmax) #elapsed=05h 10m 07s
cMMD <- lm(GMDCmat[1,] ~ poly(1:pmax,8))
plot(1:pmax,cMMD$fitted.values,type = "l")

cESC6 <- lm(GMDCmat[4,] ~ poly(1:pmax,8))
plot(1:pmax,cESC6$fitted.values,type = "l")

(apply(GMDCmat, 1, max))

pdf("Fig_GMDC.pdf")
plot(1:pmax,cMMD$fitted.values,type = "l",ylim = c(-0.01,0.45),ylab = "",
     xlab = latex2exp::TeX("$p_z$"))
lines(1:pmax,GMDCmat[2,],type = "l",lty=2,col=2)
lines(1:pmax,GMDCmat[3,],type = "l",lty=3,col=3)
lines(1:pmax,cESC6$fitted.values,type = "l",lty=4,col=4)
abline(h=0,lty=4,col="red") #the zero lower bound on variance
legend(24,0.4,c("MMD","Gauss","DL","ESC6"),lty = c(1,2,3,4),col = c(1,2,3,4))
dev.off()
par(mfrow=c(1,1))
#================================================================================>


#================================================================================>
# Compute the covariance of D and Z1 for DGP1B
# A function to compute E[sin(Z1)*sin(Z2)]
fn=function(x){
  fn0=function(y){sin(exp(-1)*x+y)*sin(x)*dnorm(y,sd=sqrt(1-exp(-2)))}
  integrate(fn0,-Inf,Inf)$value*dnorm(x)
}
fn(0)
fn(1)
fn=Vectorize(fn)
curve(fn,-3,3)
integrate(fn,-Inf,Inf)
# 0.1384086 with absolute error < 1.7e-07 #Has non-zero mean

#now compute covariance of D and Z1
ffn=function(x){
  fn0=function(y){sin(exp(-1)*x+y)*sin(x)*(exp(-1)*x+y)*dnorm(y,sd=sqrt(1-exp(-2)))}
  integrate(fn0,-Inf,Inf)$value*dnorm(x)
}
ffn(0)
ffn(1)
ffn=Vectorize(ffn)
curve(ffn,-3,3)
integrate(ffn,-Inf,Inf)
#0 with absolute error < 0 #the covariance is zero

# Verify with simulations
Sig=diag(2)
Sig[1,2]=Sig[2,1]=exp(-1)
Sig
set.seed(10)
MM = MASS::mvrnorm(n=1000000,mu=rep(0,2),Sigma = Sig)

mean(sin(MM[,1])*sin(MM[,2]))
#[1] 0.1388706 #compare mean; reasonable match

#compute covariance
mean(MM[,1]*sin(MM[,1])*sin(MM[,2]))
#[1] -0.00103842
#test for the significance of the mean
t.test(MM[,1]*sin(MM[,1])*sin(MM[,2]))
# One Sample t-test
# 
# data:  MM[, 1] * sin(MM[, 1]) * sin(MM[, 2])
# t = 0.53675, df = 1e+06, p-value = 0.5914
# alternative hypothesis: true mean is not equal to 0
# 95 percent confidence interval:
#   -0.0008137986  0.0014276356
# sample estimates:
#   mean of x 
# 0.0003069185 
#================================================================================>