#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 5, 2021
# Last Update:  March 6, 2021
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memonry,
#rm(list=ls())
library(MASS)
library(estrpac)
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations, n = 250
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=1

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------

gdat1<- function(n,f.fun,s.fun,pz,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n,rep(0,pz),exp(-as.matrix(dist(1:pz))))
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = gam*2*pnorm(as.matrix(Z)%*%rep(1,pz)) + f.fun(Z,EU[,2])
    #generate outcome
    X = Z[,2]
    Y = a + D + X + s.fun(Z,EU[,1])
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D,X),Z=Z)
  }
  datl
}

gdat2<- function(n,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n,rep(0,2),exp(-as.matrix(dist(1:2))))
    
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    set.seed(2*l+10)
    #xi = runif(n,(1-sqrt(3)),(1+sqrt(3)))
    
    #D = Z[,1]^2*(xi-(1-gam*sqrt(pi)))+EU[,2]
    D = sqrt(gam)*sin(Z[,1])*sin(Z[,2])/((1-exp(-2))/4) + EU[,2]
    #generate outcome
    
    Y = a + D + Z[,2] + EU[,1]
    
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D,Z[,2]),Z=Z)
  }
  datl
}



#transformations of Z
f.fun1=function(Z,V){
  2*apply((abs(Z)< -qnorm(1/4))*1,1,sum)/sqrt(ncol(Z)) + V
}

#skedastic function of Z,U
s.fun1=function(Z,U){ U }

# size a, n = 500
datl1a=gdat1(n=500,f.fun=f.fun1,s.fun=s.fun1,pz=2,gam = 0.0) #linear heteroskedastic model

summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z))#MMD is the default
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "Gauss.W"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "Gauss"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "DL"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "WMD"))

MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat$Y; X = as.matrix(dat$X)
  Z = as.matrix(dat$Z)
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z,Kern = "Gauss.W")
  
  #run K-Class regressions
  TSLSobj=ivreg(Y~X|Z); TSLSobj$HC_Std.Err=sqrt(diag(vcovHC(TSLSobj)))
  JIVEobj=kClassIVreg.fit(Y,X,Z,method = "JIVE")
  LIMLobj=kClassIVreg.fit(Y,X,Z,method = "LIML")
  HLIMobj=kClassIVreg.fit(Y,X,Z,method = "HLIM")
  HFULobj=kClassIVreg.fit(Y,X,Z,method = "HFUL")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  bias.TSLS = TSLSobj$coefficients[2]-b
  bias.JIVE = JIVEobj$coefficients[2]-b
  bias.LIML = LIMLobj$coefficients[2]-b
  bias.HLIM = HLIMobj$coefficients[2]-b
  bias.HFUL = HFULobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  size.TSLS = 1*(abs(bias.TSLS/TSLSobj$HC_Std.Err[2])>qnorm(0.975))
  size.JIVE = 1*(abs(bias.JIVE/JIVEobj$HC_Std.Err[2])>qnorm(0.975))
  size.LIML = 1*(abs(bias.LIML/LIMLobj$HC_Std.Err[2])>qnorm(0.975))
  size.HLIM = 1*(abs(bias.HLIM/HLIMobj$HC_Std.Err[2])>qnorm(0.975))
  size.HFUL = 1*(abs(bias.HFUL/HFULobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,bias.TSLS,bias.JIVE,bias.LIML,bias.HLIM,
        bias.HFUL,size.MMD,
        size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV,size.TSLS,size.JIVE,size.LIML,
        size.HLIM,size.HFUL)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV","Bias.TSLS",
               "Bias.JIVE","Bias.LIML","Bias.HLIM","Bias.HFUL",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV","Size.TSLS",
               "Size.JIVE","Size.LIML","Size.HLIM","Size.HFUL")
  res
}
# 
#-------------------------------------------------------

# illustration
MCfun1(j=2,datl=datl1a,b=b)

#gam=0.0
Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

#gam=0.25
datl1aM=gdat1(n=500,f.fun=f.fun1,s.fun=s.fun1,pz=2,gam = 0.25)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

# gam=0.5
datl1aMM=gdat1(n=500,f.fun=f.fun1,s.fun=s.fun1,pz=2,gam = 0.5)
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------
# n = 500
#gamma = 0.1
datl1b=gdat2(n=500,gam = 0.1)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

# gamma = 0.5
datl1bM=gdat2(n=500,gam = 0.50)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

# gamma = 1.0
datl1bMM=gdat2(n=500,gam = 1.0)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:11,],1,mean),apply(Bias1a[1:11,],1,MAD),apply(Bias1a[1:11,],1,RMSE),
                   apply(Bias1a[12:22,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:11,],1,mean),apply(Bias1a.M[1:11,],1,MAD),apply(Bias1a.M[1:11,],1,RMSE),
                   apply(Bias1a.M[12:22,],1,mean,na.rm=TRUE)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:11,],1,mean),apply(Bias1a.MM[1:11,],1,MAD),apply(Bias1a.MM[1:11,],1,RMSE),
                   apply(Bias1a.MM[12:22,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)
#         MB   MAD    RMSE   Rej      MB   MAD    RMSE   Rej     MB   MAD  RMSE   Rej
# MMD   0.000 0.041   0.062 0.054   0.000 0.040   0.062 0.052  0.000 0.039 0.061 0.051
# WMD   0.000 0.037   0.056 0.051   0.000 0.037   0.056 0.054  0.000 0.037 0.055 0.057
# WMDF  0.000 0.037   0.056 0.051   0.000 0.037   0.056 0.054  0.000 0.037 0.055 0.057
# DL    0.000 0.038   0.060 0.047   0.000 0.041   0.064 0.047  0.000 0.042 0.067 0.046
# ESC6  0.002 0.036   0.054 0.058   0.002 0.036   0.054 0.056  0.002 0.035 0.053 0.055
# IIV   0.002 0.038   0.058 0.056   0.002 0.038   0.058 0.054  0.002 0.038 0.057 0.057
# TSLS -1.208 0.781  15.955 0.005   0.697 0.331  19.261 0.017 -0.013 0.159 0.718 0.029
# JIVE  0.052 0.487  26.628 0.240 -15.908 0.479 503.475 0.110 -0.217 0.189 3.894 0.027
# LIML -1.208 0.781  15.955 0.005   0.697 0.331  19.261 0.017 -0.013 0.159 0.718 0.029
# HLIM  0.052 0.487  26.628 0.240 -15.908 0.479 503.475 0.110 -0.217 0.189 3.894 0.027
# HFUL  9.676 1.013 211.364 0.022  -0.337 0.357   8.083 0.015 -0.085 0.160 0.780 0.023

#for pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")
# MMD 0 & 0.041 & 0.062 & 0.054 & 0 & 0.04 & 0.062 & 0.052 & 0 & 0.039 & 0.061 & 0.051" 
# WMD 0 & 0.037 & 0.056 & 0.051 & 0 & 0.037 & 0.056 & 0.054 & 0 & 0.037 & 0.055 & 0.057" 
# WMDF 0 & 0.037 & 0.056 & 0.051 & 0 & 0.037 & 0.056 & 0.054 & 0 & 0.037 & 0.055 & 0.057" 
# DL 0 & 0.038 & 0.06 & 0.047 & 0 & 0.041 & 0.064 & 0.047 & 0 & 0.042 & 0.067 & 0.046" 
# ESC6 0.002 & 0.036 & 0.054 & 0.058 & 0.002 & 0.036 & 0.054 & 0.056 & 0.002 & 0.035 & 0.053 & 0.055" 
# IIV 0.002 & 0.038 & 0.058 & 0.056 & 0.002 & 0.038 & 0.058 & 0.054 & 0.002 & 0.038 & 0.057 & 0.057" 
# TSLS -1.208 & 0.781 & 15.955 & 0.005 & 0.697 & 0.331 & 19.261 & 0.017 & -0.013 & 0.159 & 0.718 & 0.029" 
# JIVE 0.052 & 0.487 & 26.628 & 0.24 & -15.908 & 0.479 & 503.475 & 0.11 & -0.217 & 0.189 & 3.894 & 0.027" 
# LIML -1.208 & 0.781 & 15.955 & 0.005 & 0.697 & 0.331 & 19.261 & 0.017 & -0.013 & 0.159 & 0.718 & 0.029" 
# HLIM 0.052 & 0.487 & 26.628 & 0.24 & -15.908 & 0.479 & 503.475 & 0.11 & -0.217 & 0.189 & 3.894 & 0.027" 
# HFUL 9.676 & 1.013 & 211.364 & 0.022 & -0.337 & 0.357 & 8.083 & 0.015 & -0.085 & 0.16 & 0.78 & 0.023"

#----------------------------------------------------------------------------------------->

Res.B1=round(cbind(apply(Bias1b[1:11,],1,mean),apply(Bias1b[1:11,],1,MAD),apply(Bias1b[1:11,],1,RMSE),
                   apply(Bias1b[12:22,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:11,],1,mean),apply(Bias1b.M[1:11,],1,MAD),apply(Bias1b.M[1:11,],1,RMSE),
                   apply(Bias1b.M[12:22,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:11,],1,mean),apply(Bias1b.MM[1:11,],1,MAD),apply(Bias1b.MM[1:11,],1,RMSE),
                   apply(Bias1b.MM[12:22,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)
#         MB   MAD   RMSE   Rej     MB   MAD   RMSE   Rej     MB   MAD   RMSE   Rej
# MMD   0.260 0.133  6.532 0.074  0.015 0.063  0.112 0.048  0.008 0.045  0.076 0.048
# WMD   0.002 0.053  0.080 0.044  0.001 0.023  0.034 0.051  0.001 0.016  0.024 0.051
# WMDF  0.003 0.053  0.079 0.044  0.001 0.023  0.034 0.051  0.001 0.016  0.024 0.052
# DL    0.105 0.129  2.518 0.072 -0.256 0.060  8.186 0.047  0.006 0.043  0.086 0.045
# ESC6  0.064 0.104  0.160 0.097  0.016 0.040  0.064 0.071  0.008 0.028  0.044 0.063
# IIV   0.025 0.063  0.092 0.065  0.006 0.028  0.040 0.054  0.004 0.019  0.028 0.053
# TSLS  4.703 0.789 90.163 0.008  0.446 0.502 10.134 0.003 -0.156 0.380  5.302 0.001
# JIVE -0.459 0.371 18.610 0.325  1.256 0.185 35.378 0.202 -1.159 0.122 37.760 0.173
# LIML  4.703 0.789 90.163 0.008  0.446 0.502 10.134 0.003 -0.156 0.380  5.302 0.001
# HLIM -0.459 0.371 18.610 0.325  1.256 0.185 35.378 0.202 -1.159 0.122 37.760 0.173
# HFUL  0.587 0.439 23.770 0.174  0.224 0.217  4.094 0.095  0.597 0.157 25.005 0.069

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")
# MMD 0.26 & 0.133 & 6.532 & 0.074 & 0.015 & 0.063 & 0.112 & 0.048 & 0.008 & 0.045 & 0.076 & 0.048" 
# WMD 0.002 & 0.053 & 0.08 & 0.044 & 0.001 & 0.023 & 0.034 & 0.051 & 0.001 & 0.016 & 0.024 & 0.051" 
# WMDF 0.003 & 0.053 & 0.079 & 0.044 & 0.001 & 0.023 & 0.034 & 0.051 & 0.001 & 0.016 & 0.024 & 0.052" 
# DL 0.105 & 0.129 & 2.518 & 0.072 & -0.256 & 0.06 & 8.186 & 0.047 & 0.006 & 0.043 & 0.086 & 0.045" 
# ESC6 0.064 & 0.104 & 0.16 & 0.097 & 0.016 & 0.04 & 0.064 & 0.071 & 0.008 & 0.028 & 0.044 & 0.063" 
# IIV 0.025 & 0.063 & 0.092 & 0.065 & 0.006 & 0.028 & 0.04 & 0.054 & 0.004 & 0.019 & 0.028 & 0.053" 
# TSLS 4.703 & 0.789 & 90.163 & 0.008 & 0.446 & 0.502 & 10.134 & 0.003 & -0.156 & 0.38 & 5.302 & 0.001" 
# JIVE -0.459 & 0.371 & 18.61 & 0.325 & 1.256 & 0.185 & 35.378 & 0.202 & -1.159 & 0.122 & 37.76 & 0.173" 
# LIML 4.703 & 0.789 & 90.163 & 0.008 & 0.446 & 0.502 & 10.134 & 0.003 & -0.156 & 0.38 & 5.302 & 0.001" 
# HLIM -0.459 & 0.371 & 18.61 & 0.325 & 1.256 & 0.185 & 35.378 & 0.202 & -1.159 & 0.122 & 37.76 & 0.173" 
# HFUL 0.587 & 0.439 & 23.77 & 0.174 & 0.224 & 0.217 & 4.094 & 0.095 & 0.597 & 0.157 & 25.005 & 0.069"

#=========================================================================================>