#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 5, 2021
# Last Update:  March 6, 2021
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(MASS)
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations, n = 250, DGP_1A and DGP_1B
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=1

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------

#DGP_1A
gdat1<- function(n,f.fun,s.fun,pz,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n,rep(0,pz),exp(-as.matrix(dist(1:pz))))
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = gam*2*pnorm(as.matrix(Z)%*%rep(1,pz)) + f.fun(Z,EU[,2])
    #generate outcome
    X = Z[,2]
    Y = a + D + X + s.fun(Z,EU[,1])
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D,X),Z=Z)
  }
  datl
}

#DGP_1B
gdat2<- function(n,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=mvrnorm(n,rep(0,2),exp(-as.matrix(dist(1:2))))
    
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    set.seed(2*l+10)

    D = sqrt(gam)*sin(Z[,1])*sin(Z[,2])/((1-exp(-2))/4) + EU[,2]
    #generate outcome
    
    Y = a + D + Z[,2] + EU[,1]
    
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D,Z[,2]),Z=Z)
  }
  datl
}


#transformations of Z
f.fun1=function(Z,V){
  2*apply((abs(Z)< -qnorm(1/4))*1,1,sum)/sqrt(ncol(Z)) + V
}

#skedastic function of Z,U
s.fun1=function(Z,U){ U }

# size a, n = 250
datl1a=gdat1(n=250,f.fun=f.fun1,s.fun=s.fun1,pz=2,gam = 0.0) #linear heteroskedastic model

summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z))#MMD is the default
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "Gauss.W"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "Gauss"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "DL"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "Esc6"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$X,Z=datl1a[[1]]$Z,Kern = "WMD"))

MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat$Y; X = as.matrix(dat$X)
  Z = as.matrix(dat$Z)
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z,Kern = "Gauss.W")
  
  #run K-Class regressions
  TSLSobj=ivreg(Y~X|Z); TSLSobj$HC_Std.Err=sqrt(diag(vcovHC(TSLSobj)))
  JIVEobj=kClassIVreg.fit(Y,X,Z,method = "JIVE")
  LIMLobj=kClassIVreg.fit(Y,X,Z,method = "LIML")
  HLIMobj=kClassIVreg.fit(Y,X,Z,method = "HLIM")
  HFULobj=kClassIVreg.fit(Y,X,Z,method = "HFUL")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  bias.TSLS = TSLSobj$coefficients[2]-b
  bias.JIVE = JIVEobj$coefficients[2]-b
  bias.LIML = LIMLobj$coefficients[2]-b
  bias.HLIM = HLIMobj$coefficients[2]-b
  bias.HFUL = HFULobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  size.TSLS = 1*(abs(bias.TSLS/TSLSobj$HC_Std.Err[2])>qnorm(0.975))
  size.JIVE = 1*(abs(bias.JIVE/JIVEobj$HC_Std.Err[2])>qnorm(0.975))
  size.LIML = 1*(abs(bias.LIML/LIMLobj$HC_Std.Err[2])>qnorm(0.975))
  size.HLIM = 1*(abs(bias.HLIM/HLIMobj$HC_Std.Err[2])>qnorm(0.975))
  size.HFUL = 1*(abs(bias.HFUL/HFULobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,bias.TSLS,bias.JIVE,bias.LIML,bias.HLIM,
        bias.HFUL,size.MMD,
        size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV,size.TSLS,size.JIVE,size.LIML,
        size.HLIM,size.HFUL)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV","Bias.TSLS",
               "Bias.JIVE","Bias.LIML","Bias.HLIM","Bias.HFUL",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV","Size.TSLS",
               "Size.JIVE","Size.LIML","Size.HLIM","Size.HFUL")
  res
}

# 
#-------------------------------------------------------

# illustration
MCfun1(j=2,datl=datl1a,b=b)

#gam=0.0
Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

#gam=0.25
datl1aM=gdat1(n=250,f.fun=f.fun1,s.fun=s.fun1,pz=2,gam = 0.25)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

# gam=0.5
datl1aMM=gdat1(n=250,f.fun=f.fun1,s.fun=s.fun1,pz=2,gam = 0.5)
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------
# size b, n = 250
#gamma = 0.1
datl1b=gdat2(n=250,gam = 0.1)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

# gamma = 0.5
datl1bM=gdat2(n=250,gam = 0.50)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

# gamma = 1.0
datl1bMM=gdat2(n=250,gam = 1.0)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:11,],1,mean),apply(Bias1a[1:11,],1,MAD),apply(Bias1a[1:11,],1,RMSE),
                   apply(Bias1a[12:22,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:11,],1,mean),apply(Bias1a.M[1:11,],1,MAD),apply(Bias1a.M[1:11,],1,RMSE),
                   apply(Bias1a.M[12:22,],1,mean)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:11,],1,mean),apply(Bias1a.MM[1:11,],1,MAD),apply(Bias1a.MM[1:11,],1,RMSE),
                   apply(Bias1a.MM[12:22,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)

#         MB   MAD   RMSE   Rej     MB   MAD    RMSE   Rej     MB   MAD  RMSE   Rej
# MMD   0.000 0.058  0.088 0.045 -0.001 0.058   0.088 0.047 -0.001 0.057 0.087 0.047
# WMD  -0.004 0.052  0.082 0.049 -0.004 0.051   0.081 0.049 -0.004 0.051 0.081 0.046
# WMDF -0.004 0.052  0.082 0.049 -0.004 0.051   0.081 0.049 -0.003 0.051 0.080 0.046
# DL    0.004 0.059  0.086 0.041  0.004 0.062   0.091 0.040  0.003 0.065 0.096 0.038
# ESC6  0.002 0.049  0.078 0.045  0.001 0.049   0.078 0.048  0.001 0.048 0.076 0.049
# IIV  -0.001 0.054  0.084 0.053 -0.001 0.054   0.084 0.050 -0.001 0.053 0.083 0.049
# TSLS  0.211 0.692  8.900 0.005 -0.807 0.423  22.877 0.007 -0.098 0.206 6.303 0.018
# JIVE -1.243 0.470 42.157 0.212 -0.154 0.560  11.296 0.152 -0.046 0.315 5.796 0.042
# LIML  0.211 0.692  8.900 0.005 -0.807 0.423  22.877 0.007 -0.098 0.206 6.303 0.018
# HLIM -1.243 0.470 42.157 0.212 -0.154 0.560  11.296 0.152 -0.046 0.315 5.796 0.042
# HFUL  0.416 0.853 43.279 0.010 24.514 0.495 785.699 0.008 -0.088 0.219 3.054 0.013

#for pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")

# MMD 0 & 0.058 & 0.088 & 0.045 & -0.001 & 0.058 & 0.088 & 0.047 & -0.001 & 0.057 & 0.087 & 0.047" 
# WMD -0.004 & 0.052 & 0.082 & 0.049 & -0.004 & 0.051 & 0.081 & 0.049 & -0.004 & 0.051 & 0.081 & 0.046" 
# WMDF -0.004 & 0.052 & 0.082 & 0.049 & -0.004 & 0.051 & 0.081 & 0.049 & -0.003 & 0.051 & 0.08 & 0.046" 
# DL 0.004 & 0.059 & 0.086 & 0.041 & 0.004 & 0.062 & 0.091 & 0.04 & 0.003 & 0.065 & 0.096 & 0.038" 
# ESC6 0.002 & 0.049 & 0.078 & 0.045 & 0.001 & 0.049 & 0.078 & 0.048 & 0.001 & 0.048 & 0.076 & 0.049" 
# IIV -0.001 & 0.054 & 0.084 & 0.053 & -0.001 & 0.054 & 0.084 & 0.05 & -0.001 & 0.053 & 0.083 & 0.049" 
# TSLS 0.211 & 0.692 & 8.9 & 0.005 & -0.807 & 0.423 & 22.877 & 0.007 & -0.098 & 0.206 & 6.303 & 0.018" 
# JIVE -1.243 & 0.47 & 42.157 & 0.212 & -0.154 & 0.56 & 11.296 & 0.152 & -0.046 & 0.315 & 5.796 & 0.042" 
# LIML 0.211 & 0.692 & 8.9 & 0.005 & -0.807 & 0.423 & 22.877 & 0.007 & -0.098 & 0.206 & 6.303 & 0.018" 
# HLIM -1.243 & 0.47 & 42.157 & 0.212 & -0.154 & 0.56 & 11.296 & 0.152 & -0.046 & 0.315 & 5.796 & 0.042" 
# HFUL 0.416 & 0.853 & 43.279 & 0.01 & 24.514 & 0.495 & 785.699 & 0.008 & -0.088 & 0.219 & 3.054 & 0.013"
#----------------------------------------------------------------------------------------->

Res.B1=round(cbind(apply(Bias1b[1:11,],1,mean),apply(Bias1b[1:11,],1,MAD),apply(Bias1b[1:11,],1,RMSE),
                   apply(Bias1b[12:22,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:11,],1,mean),apply(Bias1b.M[1:11,],1,MAD),apply(Bias1b.M[1:11,],1,RMSE),
                   apply(Bias1b.M[12:22,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:11,],1,mean),apply(Bias1b.MM[1:11,],1,MAD),apply(Bias1b.MM[1:11,],1,RMSE),
                   apply(Bias1b.MM[12:22,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)

#         MB   MAD   RMSE   Rej     MB   MAD   RMSE   Rej     MB   MAD   RMSE   Rej
# MMD   0.171 0.162  2.792 0.069  0.016 0.079  0.200 0.047  0.010 0.056  0.130 0.038
# WMD  -0.006 0.079  0.118 0.031 -0.003 0.034  0.049 0.037 -0.002 0.024  0.035 0.036
# WMDF -0.003 0.078  0.117 0.033 -0.002 0.034  0.049 0.039 -0.002 0.023  0.035 0.037
# DL    0.073 0.177  3.362 0.068  0.026 0.091  0.475 0.038  0.065 0.065  1.508 0.035
# ESC6  0.089 0.143  0.275 0.091  0.017 0.058  0.101 0.052  0.008 0.042  0.066 0.047
# IIV   0.032 0.092  0.127 0.059  0.005 0.039  0.056 0.049  0.001 0.028  0.040 0.048
# TSLS  0.376 0.733  9.171 0.005 -0.065 0.483 14.444 0.000  0.209 0.363  5.691 0.000
# JIVE -0.619 0.400 35.945 0.302 -0.413 0.187 13.922 0.187 -0.101 0.123  5.889 0.128
# LIML  0.376 0.733  9.171 0.005 -0.065 0.483 14.444 0.000  0.209 0.363  5.691 0.000
# HLIM -0.619 0.400 35.945 0.302 -0.413 0.187 13.922 0.187 -0.101 0.123  5.889 0.128
# HFUL -0.909 0.437 39.869 0.135  0.006 0.219 10.168 0.066 -0.736 0.150 17.356 0.042

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")

# MMD 0.171 & 0.162 & 2.792 & 0.069 & 0.016 & 0.079 & 0.2 & 0.047 & 0.01 & 0.056 & 0.13 & 0.038" 
# WMD -0.006 & 0.079 & 0.118 & 0.031 & -0.003 & 0.034 & 0.049 & 0.037 & -0.002 & 0.024 & 0.035 & 0.036" 
# WMDF -0.003 & 0.078 & 0.117 & 0.033 & -0.002 & 0.034 & 0.049 & 0.039 & -0.002 & 0.023 & 0.035 & 0.037" 
# DL 0.073 & 0.177 & 3.362 & 0.068 & 0.026 & 0.091 & 0.475 & 0.038 & 0.065 & 0.065 & 1.508 & 0.035" 
# ESC6 0.089 & 0.143 & 0.275 & 0.091 & 0.017 & 0.058 & 0.101 & 0.052 & 0.008 & 0.042 & 0.066 & 0.047" 
# IIV 0.032 & 0.092 & 0.127 & 0.059 & 0.005 & 0.039 & 0.056 & 0.049 & 0.001 & 0.028 & 0.04 & 0.048" 
# TSLS 0.376 & 0.733 & 9.171 & 0.005 & -0.065 & 0.483 & 14.444 & 0 & 0.209 & 0.363 & 5.691 & 0" 
# JIVE -0.619 & 0.4 & 35.945 & 0.302 & -0.413 & 0.187 & 13.922 & 0.187 & -0.101 & 0.123 & 5.889 & 0.128" 
# LIML 0.376 & 0.733 & 9.171 & 0.005 & -0.065 & 0.483 & 14.444 & 0 & 0.209 & 0.363 & 5.691 & 0" 
# HLIM -0.619 & 0.4 & 35.945 & 0.302 & -0.413 & 0.187 & 13.922 & 0.187 & -0.101 & 0.123 & 5.889 & 0.128" 
# HFUL -0.909 & 0.437 & 39.869 & 0.135 & 0.006 & 0.219 & 10.168 & 0.066 & -0.736 & 0.15 & 17.356 & 0.042"

#=========================================================================================>



# Compute F-statistics of DGP1A for all levels of delta

FS_FStat.M<- function(j,datl){
  robj=lm(datl[[j]]$X[,1]~datl[[j]]$Z)
  ans=(robj$coefficients[2]/sqrt(diag(vcov(robj)))[2])^2
  names(ans)="F_Stat"
  ans
}


FS_M=sapply(1:R,FS_FStat.M,datl=datl1aM)
summary(FS_M)
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 0.000006  0.297894  1.290752  2.071816  2.856269 18.288076 
datl1aMM

FS_MM=sapply(1:R,FS_FStat.M,datl=datl1aMM)
summary(FS_MM)
# Min.   1st Qu.    Median      Mean   3rd Qu.      Max. 
# 0.000013  2.153424  4.681212  5.485983  7.601441 30.695537




