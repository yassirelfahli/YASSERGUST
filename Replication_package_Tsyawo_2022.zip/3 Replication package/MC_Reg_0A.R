#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 28, 2021
# Last Update:  Sept 28, 2021
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(MASS)
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations, n = 250 & n = 500, DGP_0A
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=1

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------
# specification without excluded instrument
gdat1<- function(n,gam){
  datl=list()
  for (l in 1:R) {
    set.seed(l) #generate seed
    Z=rnorm(n)
    
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.5
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = 1/4 + Z + sqrt(gam)*Z^2 + EU[,2]
    #generate outcome
    Y = a + D + Z + EU[,1]
    
    #save in a list
    datl[[l]]<- list(Y=Y,X=cbind(D,Z),Z=Z)
  }
  datl
}

MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat$Y; X = as.matrix(dat$X)
  Z = as.matrix(dat$Z)
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z,Kern = "Gauss.W")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,
        size.MMD,size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV")
  res
}

# 
#-------------------------------------------------------
#n = 250
datl1a=gdat1(n=250,gam = 0.1)
#illustration
MCfun1(j=1,datl = datl1a,b=b)

Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

#n = 250
datl1aM=gdat1(n=250,gam = 0.5)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

#n = 250
datl1aMM=gdat1(n=250,gam = 1.0)
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------

#-------------------------------------------------------
# specification b
#n = 500
datl1b=gdat1(n=500,gam = 0.1)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

#n = 500
datl1bM=gdat1(n=500,gam = 0.5)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

#n = 500
datl1bMM=gdat1(n=500,gam = 1.0)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:6,],1,mean),apply(Bias1a[1:6,],1,MAD),
                   apply(Bias1a[1:6,],1,RMSE),
                   apply(Bias1a[7:12,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:6,],1,mean),apply(Bias1a.M[1:6,],1,MAD),
                   apply(Bias1a.M[1:6,],1,RMSE),
                   apply(Bias1a.M[7:12,],1,mean)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:6,],1,mean),apply(Bias1a.MM[1:6,],1,MAD),
                   apply(Bias1a.MM[1:6,],1,RMSE),
                   apply(Bias1a.MM[7:12,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)
#         MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD  -0.024 0.098 0.163 0.044 -0.005 0.044 0.067 0.058 -0.003 0.030 0.047 0.060
# WMD  -0.017 0.097 0.167 0.051 -0.009 0.050 0.119 0.051  0.012 0.040 0.246 0.052
# WMDF -0.020 0.098 0.170 0.048 -0.012 0.049 0.129 0.051  0.011 0.041 0.281 0.053
# DL   -0.048 0.126 0.226 0.035 -0.013 0.057 0.094 0.047 -0.008 0.041 0.067 0.048
# ESC6 -0.038 0.112 0.190 0.030 -0.009 0.047 0.074 0.040 -0.005 0.033 0.051 0.042
# IIV  -0.028 0.100 0.174 0.045 -0.015 0.050 0.138 0.054 -0.016 0.042 0.422 0.055

#writing out output to pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")
# MMD -0.024 & 0.098 & 0.163 & 0.044 & -0.005 & 0.044 & 0.067 & 0.058 & -0.003 & 0.03 & 0.047 & 0.06" 
# WMD -0.017 & 0.097 & 0.167 & 0.051 & -0.009 & 0.05 & 0.119 & 0.051 & 0.012 & 0.04 & 0.246 & 0.052" 
# WMDF -0.02 & 0.098 & 0.17 & 0.048 & -0.012 & 0.049 & 0.129 & 0.051 & 0.011 & 0.041 & 0.281 & 0.053" 
# DL -0.048 & 0.126 & 0.226 & 0.035 & -0.013 & 0.057 & 0.094 & 0.047 & -0.008 & 0.041 & 0.067 & 0.048" 
# ESC6 -0.038 & 0.112 & 0.19 & 0.03 & -0.009 & 0.047 & 0.074 & 0.04 & -0.005 & 0.033 & 0.051 & 0.042" 
# IIV -0.028 & 0.1 & 0.174 & 0.045 & -0.015 & 0.05 & 0.138 & 0.054 & -0.016 & 0.042 & 0.422 & 0.055"
#=========================================================================================>
Res.B1=round(cbind(apply(Bias1b[1:6,],1,mean),apply(Bias1b[1:6,],1,MAD),
                   apply(Bias1b[1:6,],1,RMSE),
                   apply(Bias1b[7:12,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:6,],1,mean),apply(Bias1b.M[1:6,],1,MAD),
                   apply(Bias1b.M[1:6,],1,RMSE),
                   apply(Bias1b.M[7:12,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:6,],1,mean),apply(Bias1b.MM[1:6,],1,MAD),
                   apply(Bias1b.MM[1:6,],1,RMSE),
                   apply(Bias1b.MM[7:12,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)
#         MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD  -0.008 0.066 0.105 0.051 -0.001 0.030 0.046 0.057  0.000 0.021 0.032 0.054
# WMD  -0.004 0.066 0.104 0.054  0.000 0.033 0.051 0.059  0.000 0.027 0.043 0.063
# WMDF -0.005 0.066 0.104 0.053 -0.001 0.033 0.051 0.059  0.000 0.027 0.043 0.063
# DL   -0.023 0.087 0.141 0.031 -0.007 0.041 0.063 0.044 -0.004 0.030 0.046 0.049
# ESC6 -0.015 0.073 0.116 0.034 -0.004 0.032 0.049 0.038 -0.002 0.023 0.034 0.040
# IIV  -0.009 0.067 0.105 0.050 -0.003 0.033 0.052 0.061 -0.001 0.027 0.044 0.063

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")
# MMD -0.008 & 0.066 & 0.105 & 0.051 & -0.001 & 0.03 & 0.046 & 0.057 & 0 & 0.021 & 0.032 & 0.054" 
# WMD -0.004 & 0.066 & 0.104 & 0.054 & 0 & 0.033 & 0.051 & 0.059 & 0 & 0.027 & 0.043 & 0.063" 
# WMDF -0.005 & 0.066 & 0.104 & 0.053 & -0.001 & 0.033 & 0.051 & 0.059 & 0 & 0.027 & 0.043 & 0.063" 
# DL -0.023 & 0.087 & 0.141 & 0.031 & -0.007 & 0.041 & 0.063 & 0.044 & -0.004 & 0.03 & 0.046 & 0.049" 
# ESC6 -0.015 & 0.073 & 0.116 & 0.034 & -0.004 & 0.032 & 0.049 & 0.038 & -0.002 & 0.023 & 0.034 & 0.04" 
# IIV -0.009 & 0.067 & 0.105 & 0.05 & -0.003 & 0.033 & 0.052 & 0.061 & -0.001 & 0.027 & 0.044 & 0.063"
#=========================================================================================>


#=========================================================================================>