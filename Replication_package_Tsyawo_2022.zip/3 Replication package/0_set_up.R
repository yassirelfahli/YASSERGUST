#this file installs R packages needed for replication
devtools::install_github("estsyawo/estrpac") 
#or install from binary file estrpac_0.1.0.tgz provided in the replication folder
install.packages("pbapply")
install.packages("AER")
install.packages("sandwich")
install.packages("rstudioapi")
