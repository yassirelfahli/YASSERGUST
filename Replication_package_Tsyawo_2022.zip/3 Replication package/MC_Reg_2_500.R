#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept 5, 2021
# Last Update:  Sept 11, 2021
# Place:        Rabat
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(MASS)
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(pbapply)
library(AER)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
#source("Fonctions.R")
list.files()
#=========================================================================================>
# Comments: Monte Carlo Simulations using the DGP of Antoine & Lavergne 2014 (section 5)
# n = 500; DGP_2A & DGP_2B
#=========================================================================================>
# Set Parameters
R = 1000 # set number of simulations
a=b=0 #set parameters
#B=499 # number of non-parametric bootstrap samples

RMSE = function(x) sqrt(mean(x^2))
MAD = function(x) median(abs(x))

#-------------------------------------------------------
# ... pz must be an even number
gdat1<- function(n,f.fun,s.fun,gam,pz=12){
  datl=list(); K = pz/2; C=8
  for (l in 1:R) {
    set.seed(l) #generate seed
    X=rnorm(n)
    Sig = diag(2); Sig[1,2]=Sig[2,1]=0.8
    set.seed(l+10)
    EU=mvrnorm(n=n,mu=c(0,0),Sigma = Sig)
    #generate endogenous covariate
    D = n^(-gam)*sqrt(C)*f.fun(X) + EU[,2]
    #generate outcome
    Y = a + b*D + s.fun(X)*EU[,1]
    #generate instruments
    I = (0:K)/K #intervals
    Z = matrix(NA,n,pz-1)
    Z[,1]=X
    for (j in 2:K) {
      #cat("at j = ",j,", indices are ",c(2*(j-1),2*(j-1)+1),"\n")
      Z[,2*(j-1)]= ((qnorm(I[j-1])<=X)&(X<=qnorm(I[j])))*1
      Z[,2*(j-1)+1]=X*Z[,2*(j-1)]
    }
    datl[[l]]<- data.frame(Y,D,Z)
  }
  datl
}
#transformations of x
f.fun1=function(x){x}; f.fun2=function(x){sqrt(2*pi*sqrt(27))*x*exp(-x^2/2)}
#skedastic function of x
s.fun1=function(x){sqrt((1+x^2)/2)}; s.fun2=function(x){1}

# size a, n = 500
datl1a=gdat1(n=500,f.fun=f.fun1,s.fun=s.fun1,gam = 0.45,pz=12) #linear heteroskedastic model

summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)]))#MMD is the default
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss.W"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "Gauss"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "DL"))
summary(imlmreg2.fit(Y=datl1a[[1]]$Y,X=datl1a[[1]]$D,Z=datl1a[[1]][,-c(1,2)],Kern = "WMD"))

MCfun1<- function(j=NULL,datl,b){
  dat = datl[[j]] #null operation for looping
  Y = dat[,1]; X = as.matrix(dat[,2])
  Z1 = as.matrix(dat[,3]); Z2 = as.matrix(dat[,-c(1,2)])
  
  #run Integrated Moment regressions
  MMDobj=imlmreg2.fit(Y,X,Z1,Kern = "Euclid")
  WMDobj=imlmreg2.fit(Y,X,Z1,Kern = "WMD")
  WMDFobj=imlmreg2.fit(Y,X,Z1,Kern = "WMDF")
  DLobj=imlmreg2.fit(Y,X,Z1,Kern = "DL")
  Esc6obj=imlmreg2.fit(Y,X,Z1,Kern = "Esc6")
  IIVobj=imlmreg2.fit(Y,X,Z1,Kern = "Gauss.W")
  #run K-Class regressions
  TSLSobj=ivreg(Y~X|Z2); TSLSobj$HC_Std.Err=sqrt(diag(vcovHC(TSLSobj)))
  JIVEobj=kClassIVreg.fit(Y,X,Z2,method = "JIVE")
  LIMLobj=kClassIVreg.fit(Y,X,Z2,method = "LIML")
  HLIMobj=kClassIVreg.fit(Y,X,Z2,method = "HLIM")
  HFULobj=kClassIVreg.fit(Y,X,Z2,method = "HFUL")
  
  #compute bias
  bias.MMD = MMDobj$coefficients[2]-b 
  bias.WMD = WMDobj$coefficients[2]-b
  bias.WMDF = WMDFobj$coefficients[2]-b
  bias.DL = DLobj$coefficients[2]-b
  bias.Esc6 = Esc6obj$coefficients[2]-b
  bias.IIV = IIVobj$coefficients[2]-b
  
  bias.TSLS = TSLSobj$coefficients[2]-b
  bias.JIVE = JIVEobj$coefficients[2]-b
  bias.LIML = LIMLobj$coefficients[2]-b
  bias.HLIM = HLIMobj$coefficients[2]-b
  bias.HFUL = HFULobj$coefficients[2]-b
  
  #compute size (for rejection probabilities)
  size.MMD = 1*(abs(bias.MMD/MMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMD = 1*(abs(bias.WMD/WMDobj$HC_Std.Err[2])>qnorm(0.975))
  size.WMDF = 1*(abs(bias.WMDF/WMDFobj$HC_Std.Err[2])>qnorm(0.975))
  size.DL = 1*(abs(bias.DL/DLobj$HC_Std.Err[2])>qnorm(0.975))
  size.Esc6 = 1*(abs(bias.Esc6/Esc6obj$HC_Std.Err[2])>qnorm(0.975))
  size.IIV = 1*(abs(bias.IIV/IIVobj$HC_Std.Err[2])>qnorm(0.975))
  
  size.TSLS = 1*(abs(bias.TSLS/TSLSobj$HC_Std.Err[2])>qnorm(0.975))
  size.JIVE = 1*(abs(bias.JIVE/JIVEobj$HC_Std.Err[2])>qnorm(0.975))
  size.LIML = 1*(abs(bias.LIML/LIMLobj$HC_Std.Err[2])>qnorm(0.975))
  size.HLIM = 1*(abs(bias.HLIM/HLIMobj$HC_Std.Err[2])>qnorm(0.975))
  size.HFUL = 1*(abs(bias.HFUL/HFULobj$HC_Std.Err[2])>qnorm(0.975))
  
  res=c(bias.MMD,bias.WMD,bias.WMDF,bias.DL,bias.Esc6,bias.IIV,bias.TSLS,bias.JIVE,bias.LIML,bias.HLIM,
        bias.HFUL,size.MMD,
        size.WMD,size.WMDF,size.DL,size.Esc6,size.IIV,size.TSLS,size.JIVE,size.LIML,
        size.HLIM,size.HFUL)
  names(res)=c("BiasMMD","BiasWMD","BiasWMDF","BiasDL","BiasEsc6","BiasIIV","Bias.TSLS",
               "Bias.JIVE","Bias.LIML","Bias.HLIM","Bias.HFUL",
               "SizeMMD","SizeWMD","SizeWMDF","SizeDL","SizeEsc6","SizeIIV","Size.TSLS",
               "Size.JIVE","Size.LIML","Size.HLIM","Size.HFUL")
  res
}


#-------------------------------------------------------

# illustration
MCfun1(j=2,datl=datl1a,b=b)

#linear heteroskedastic model, n = 250, gamma = 0.45
Bias1a = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1a,b=b)
summary(t(Bias1a))

# gamma = 0.3
datl1aM=gdat1(n=500,f.fun=f.fun1,s.fun=s.fun1,gam = 0.30)
Bias1a.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aM,b=b)
summary(t(Bias1a.M))

# gamma = 0.15
datl1aMM=gdat1(n=500,f.fun=f.fun1,s.fun=s.fun1,gam = 0.15) #linear heteroskedastic model
Bias1a.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1aMM,b=b)
summary(t(Bias1a.MM))
#-------------------------------------------------------

#gamma = 0.45
datl1b=gdat1(n=500,f.fun=f.fun2,s.fun=s.fun1,gam = 0.45)
Bias1b = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1b,b=b)
summary(t(Bias1b))

# gamma = 0.3
datl1bM=gdat1(n=500,f.fun=f.fun2,s.fun=s.fun1,gam = 0.30)
Bias1b.M = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bM,b=b)
summary(t(Bias1b.M))

# gamma = 0.15
datl1bMM=gdat1(n=500,f.fun=f.fun2,s.fun=s.fun1,gam = 0.15)
Bias1b.MM = pbsapply(1:R, FUN=MCfun1,cl=5,datl=datl1bMM,b=b)
summary(t(Bias1b.MM))
#=========================================================================================>

# Results:

Res.A1=round(cbind(apply(Bias1a[1:11,],1,mean),apply(Bias1a[1:11,],1,MAD),apply(Bias1a[1:11,],1,RMSE),
                   apply(Bias1a[12:22,],1,mean)),3)
colnames(Res.A1)=c("MB","MAD","RMSE","Rej")
rownames(Res.A1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A1

Res.A2=round(cbind(apply(Bias1a.M[1:11,],1,mean),apply(Bias1a.M[1:11,],1,MAD),apply(Bias1a.M[1:11,],1,RMSE),
                   apply(Bias1a.M[12:22,],1,mean,na.rm=TRUE)),3)
colnames(Res.A2)=c("MB","MAD","RMSE","Rej")
rownames(Res.A2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A2

Res.A3=round(cbind(apply(Bias1a.MM[1:11,],1,mean),apply(Bias1a.MM[1:11,],1,MAD),apply(Bias1a.MM[1:11,],1,RMSE),
                   apply(Bias1a.MM[12:22,],1,mean)),3)
colnames(Res.A3)=c("MB","MAD","RMSE","Rej")
rownames(Res.A3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.A3

cbind(Res.A1,Res.A2,Res.A3)

#         MB   MAD   RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD  -0.017 0.193  0.418 0.067 -0.003 0.078 0.125 0.049 -0.001 0.031 0.049 0.039
# WMD  -0.047 0.204  1.670 0.054 -0.011 0.079 0.124 0.048 -0.001 0.031 0.047 0.044
# WMDF  0.126 0.202  6.750 0.055 -0.011 0.078 0.123 0.048 -0.001 0.031 0.047 0.044
# DL   -0.132 0.190  2.981 0.068 -0.005 0.077 0.122 0.047 -0.001 0.031 0.047 0.040
# ESC6 -0.026 0.184  0.347 0.066 -0.005 0.077 0.122 0.048 -0.001 0.031 0.047 0.041
# IIV  -0.004 0.196  0.358 0.075  0.000 0.077 0.120 0.052  0.000 0.031 0.047 0.045
# TSLS  0.306 0.315  0.373 0.365  0.065 0.095 0.138 0.105  0.010 0.035 0.053 0.050
# JIVE  1.241 0.327 64.119 0.046 -0.036 0.091 0.157 0.032 -0.006 0.035 0.054 0.038
# LIML -0.189 0.234  2.220 0.053 -0.016 0.088 0.146 0.035 -0.003 0.035 0.054 0.040
# HLIM  0.357 1.556 27.494 0.108 -0.135 0.130 0.252 0.034 -0.018 0.036 0.058 0.047
# HFUL -0.217 1.300 27.413 0.082 -0.123 0.122 0.238 0.035 -0.017 0.036 0.057 0.046

#for pasting into TeX
apply(cbind(Res.A1,Res.A2,Res.A3),1,paste,collapse=" & ")

# MMD -0.017 & 0.193 & 0.418 & 0.067 & -0.003 & 0.078 & 0.125 & 0.049 & -0.001 & 0.031 & 0.049 & 0.039" 
# WMD -0.047 & 0.204 & 1.67 & 0.054 & -0.011 & 0.079 & 0.124 & 0.048 & -0.001 & 0.031 & 0.047 & 0.044" 
# WMDF 0.126 & 0.202 & 6.75 & 0.055 & -0.011 & 0.078 & 0.123 & 0.048 & -0.001 & 0.031 & 0.047 & 0.044" 
# DL -0.132 & 0.19 & 2.981 & 0.068 & -0.005 & 0.077 & 0.122 & 0.047 & -0.001 & 0.031 & 0.047 & 0.04" 
# ESC6 -0.026 & 0.184 & 0.347 & 0.066 & -0.005 & 0.077 & 0.122 & 0.048 & -0.001 & 0.031 & 0.047 & 0.041" 
# IIV -0.004 & 0.196 & 0.358 & 0.075 & 0 & 0.077 & 0.12 & 0.052 & 0 & 0.031 & 0.047 & 0.045" 
# TSLS 0.306 & 0.315 & 0.373 & 0.365 & 0.065 & 0.095 & 0.138 & 0.105 & 0.01 & 0.035 & 0.053 & 0.05" 
# JIVE 1.241 & 0.327 & 64.119 & 0.046 & -0.036 & 0.091 & 0.157 & 0.032 & -0.006 & 0.035 & 0.054 & 0.038" 
# LIML -0.189 & 0.234 & 2.22 & 0.053 & -0.016 & 0.088 & 0.146 & 0.035 & -0.003 & 0.035 & 0.054 & 0.04" 
# HLIM 0.357 & 1.556 & 27.494 & 0.108 & -0.135 & 0.13 & 0.252 & 0.034 & -0.018 & 0.036 & 0.058 & 0.047" 
# HFUL -0.217 & 1.3 & 27.413 & 0.082 & -0.123 & 0.122 & 0.238 & 0.035 & -0.017 & 0.036 & 0.057 & 0.046"

#----------------------------------------------------------------------------------------->

Res.B1=round(cbind(apply(Bias1b[1:11,],1,mean),apply(Bias1b[1:11,],1,MAD),apply(Bias1b[1:11,],1,RMSE),
                   apply(Bias1b[12:22,],1,mean)),3)
colnames(Res.B1)=c("MB","MAD","RMSE","Rej")
rownames(Res.B1)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B1

Res.B2=round(cbind(apply(Bias1b.M[1:11,],1,mean),apply(Bias1b.M[1:11,],1,MAD),apply(Bias1b.M[1:11,],1,RMSE),
                   apply(Bias1b.M[12:22,],1,mean)),3)
colnames(Res.B2)=c("MB","MAD","RMSE","Rej")
rownames(Res.B2)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B2

Res.B3=round(cbind(apply(Bias1b.MM[1:11,],1,mean),apply(Bias1b.MM[1:11,],1,MAD),apply(Bias1b.MM[1:11,],1,RMSE),
                   apply(Bias1b.MM[12:22,],1,mean)),3)
colnames(Res.B3)=c("MB","MAD","RMSE","Rej")
rownames(Res.B3)=c("MMD","WMD","WMDF","DL","ESC6","IIV","TSLS","JIVE","LIML","HLIM","HFUL")
Res.B3

cbind(Res.B1,Res.B2,Res.B3)

#         MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej     MB   MAD  RMSE   Rej
# MMD  -0.001 0.079 0.124 0.049  0.000 0.031 0.049 0.040  0.000 0.012 0.019 0.043
# WMD  -0.009 0.073 0.111 0.044 -0.001 0.029 0.043 0.039  0.000 0.011 0.017 0.038
# WMDF -0.009 0.073 0.111 0.047 -0.001 0.029 0.043 0.039  0.000 0.011 0.017 0.038
# DL   -0.004 0.076 0.119 0.048 -0.001 0.030 0.047 0.041  0.000 0.012 0.018 0.044
# ESC6 -0.004 0.077 0.120 0.048 -0.001 0.030 0.047 0.040  0.000 0.012 0.018 0.045
# IIV   0.001 0.072 0.108 0.053  0.001 0.029 0.042 0.042  0.000 0.011 0.017 0.039
# TSLS  0.076 0.087 0.118 0.164  0.013 0.029 0.041 0.076  0.002 0.011 0.016 0.044
# JIVE -0.030 0.083 0.135 0.040 -0.003 0.030 0.045 0.043  0.000 0.011 0.017 0.044
# LIML -0.013 0.072 0.122 0.031 -0.001 0.028 0.044 0.038  0.000 0.011 0.017 0.041
# HLIM -0.148 0.130 0.253 0.039 -0.017 0.032 0.049 0.054 -0.002 0.012 0.017 0.044
# HFUL -0.134 0.120 0.236 0.035 -0.016 0.032 0.049 0.053 -0.002 0.012 0.017 0.043

#for pasting into TeX
apply(cbind(Res.B1,Res.B2,Res.B3),1,paste,collapse=" & ")

# MMD -0.001 & 0.079 & 0.124 & 0.049 & 0 & 0.031 & 0.049 & 0.04 & 0 & 0.012 & 0.019 & 0.043" 
# WMD -0.009 & 0.073 & 0.111 & 0.044 & -0.001 & 0.029 & 0.043 & 0.039 & 0 & 0.011 & 0.017 & 0.038" 
# WMDF -0.009 & 0.073 & 0.111 & 0.047 & -0.001 & 0.029 & 0.043 & 0.039 & 0 & 0.011 & 0.017 & 0.038" 
# DL -0.004 & 0.076 & 0.119 & 0.048 & -0.001 & 0.03 & 0.047 & 0.041 & 0 & 0.012 & 0.018 & 0.044" 
# ESC6 -0.004 & 0.077 & 0.12 & 0.048 & -0.001 & 0.03 & 0.047 & 0.04 & 0 & 0.012 & 0.018 & 0.045" 
# IIV 0.001 & 0.072 & 0.108 & 0.053 & 0.001 & 0.029 & 0.042 & 0.042 & 0 & 0.011 & 0.017 & 0.039" 
# TSLS 0.076 & 0.087 & 0.118 & 0.164 & 0.013 & 0.029 & 0.041 & 0.076 & 0.002 & 0.011 & 0.016 & 0.044" 
# JIVE -0.03 & 0.083 & 0.135 & 0.04 & -0.003 & 0.03 & 0.045 & 0.043 & 0 & 0.011 & 0.017 & 0.044" 
# LIML -0.013 & 0.072 & 0.122 & 0.031 & -0.001 & 0.028 & 0.044 & 0.038 & 0 & 0.011 & 0.017 & 0.041" 
# HLIM -0.148 & 0.13 & 0.253 & 0.039 & -0.017 & 0.032 & 0.049 & 0.054 & -0.002 & 0.012 & 0.017 & 0.044" 
# HFUL -0.134 & 0.12 & 0.236 & 0.035 & -0.016 & 0.032 & 0.049 & 0.053 & -0.002 & 0.012 & 0.017 & 0.043"

#=========================================================================================>