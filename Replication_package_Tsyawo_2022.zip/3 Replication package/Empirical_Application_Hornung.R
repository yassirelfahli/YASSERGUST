# Empirical Application
#=========================================================================================>
# Author: Emmanuel Selorm Tsyawo
# Project: Feasible IV Regression without Excluded Instruments
# Date began:   Sept. 12, 2021
# Last Update:  Sept. 18, 2021
# Place:        Rabat
# Purpose: Empirical Application using Hornung 2014.
#=========================================================================================>
# Load packages, clear memory,
#rm(list=ls())
library(estrpac)#install from binary file estrpac_0.1.0.tgz or
# use devtools::install_github("estsyawo/estrpac")
library(AER)
library(sandwich)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) #set working directory path to source file
list.files()
#=========================================================================================>
# set values
B = 999 #number of bootstrap samples
#==============================================================================>
# read in data
hornung_data = read.table("hornung_data_textiles.txt", header = TRUE,row.names = NULL)
names(hornung_data)

#---------------------------------------------------------
#variable names as in the stata do file
mixlist=c("ln_workers1802_all", "ln_looms1802_all", "mi_ln_input1802_all", 
          "no_looms", "ln_popcity1802", "vieh1816_schaf_ganz_veredelt_pc",
          "pop1816_prot_pc", "no_hugue_possible", "imputed_dummy")
#all variables to be used
vars.all = c("ln_output1802_all", "hugue_1700_pc",mixlist, "textil_1680_dummy",
             "poploss_keyser","poploss_keyser_projected","groupid")

fml<- paste("ln_output1802_all ~", paste(vars.all[-1],collapse=" + "))
daten<-model.frame(formula = as.formula(fml),data=hornung_data) #extract data frame
dim(daten)
# [1] 150  15
# same 150 observations used in Table 4 of Hornung (2014)
N = nrow(daten)
#==============================================================================>


#=========================================================================================>
# Regressions (Table 4 in Hornung 2014)
# OLS Estimation

# column 1
fml_4.1<- paste("ln_output1802_all ~", paste(c("hugue_1700_pc",mixlist,"textil_1680_dummy"),collapse="+"))
OLS_4.1<-lm(data = daten,formula = as.formula(fml_4.1),x = TRUE, y = TRUE)
OLS_4.1$HC_Std.Err=sqrt(diag(vcovHC(OLS_4.1))) #compute heteroskedasticity-robust standard errors
dim(OLS_4.1$x) #12
#----------------------------------
#specification testing
OLS_4.1_SU=speclmb.test(reg.Obj = OLS_4.1,B=B,cl=5)
#**************************************************************************************
#*MMD Estimation

MMDIV_1<- imlmreg2.fit(Y=OLS_4.1$y,X=as.matrix(OLS_4.1$x[,-1]),Z=as.matrix(OLS_4.1$x[,-1]))

#specification testing
MMDIV_1_SU=speclmb.test(reg.Obj = MMDIV_1,B=B,cl=5)
#=========================================================================================>
# Second Column Table 4

# Relevance (IV)
# See Stata do-file Empirical_Application_KP_Rank_Test.do
#----------------------------------
# 2nd Stage (IV)
fml_IV_4.2<- paste("ln_output1802_all ~", paste(c("hugue_1700_pc",mixlist,"textil_1680_dummy"),collapse="+"),
                "|",paste(c("poploss_keyser",mixlist,"textil_1680_dummy"),collapse="+"))
IV_4.2=AER::ivreg(formula = fml_IV_4.2,data = daten,x = TRUE,y=TRUE)
IV_4.2$HC_Std.Err=sqrt(diag(vcovHC(IV_4.2))) #compute heteroskedasticity-robust standard errors
#----------------------------------
#specification testing
IV_4.2_SU=speclmb.test(reg.Obj = IV_4.2,B=B,cl=5)
#**************************************************************************************
#*MMDIV Estimation

MMDIV_2<- imlmreg2.fit(Y=IV_4.2$y,X=as.matrix(IV_4.2$x$regressors[,-1]),
                      Z = as.matrix(IV_4.2$x$instruments[,-1]))
#------------------------------------------
#specification testing
MMDIV_2_SU=speclmb.test(reg.Obj = MMDIV_2,B=B,cl=5)
#------------------------------------------
# relevance testing
MMDIV_2_rel.Obj=imlmreg2.fit(IV_4.2$x$regressors[,2],IV_4.2$x$regressors[,-c(1,2)],IV_4.2$x$instruments[,-1])
MMDIV_2_rel=speclmb.test(reg.Obj = MMDIV_2_rel.Obj,B=B,cl=5) #testable using an ICM specification test
#=========================================================================================>
# Third Column Table 4

# Relevance (IV)
# See Stata do-file Empirical_Application_KP_Rank_Test.do
#----------------------------------
# 2nd Stage (IV)
fml_IV_4.3<- paste("ln_output1802_all ~", paste(c("hugue_1700_pc",mixlist,"textil_1680_dummy"),collapse="+"),
                   "|",paste(c("poploss_keyser_projected",mixlist,"textil_1680_dummy"),collapse="+"))
IV_4.3=AER::ivreg(formula = fml_IV_4.3,data = daten,x=TRUE,y=TRUE)
IV_4.3$HC_Std.Err=sqrt(diag(vcovHC(IV_4.3)))#compute heteroskedasticity-robust standard errors
#------------------------------------------
#specification testing
IV_4.3_SU=speclmb.test(reg.Obj = IV_4.3,B=B,cl=5)
#**************************************************************************************
# MMD Estimation
MMDIV_3<- imlmreg2.fit(Y=IV_4.3$y,X=as.matrix(IV_4.3$x$regressors[,-1]),
                      Z = as.matrix(IV_4.3$x$instruments[,-1]))
#------------------------------------------
# specification testing
MMDIV_3_SU=speclmb.test(reg.Obj = MMDIV_3,B=B,cl=5)
#------------------------------------------
# relevance testing
MMDIV_3_rel.Obj=imlmreg2.fit(IV_4.3$x$regressors[,2],IV_4.3$x$regressors[,-c(1,2)],
                             IV_4.3$x$instruments[,-1])
MMDIV_3_rel=speclmb.test(reg.Obj = MMDIV_3_rel.Obj,B=B,cl=5)
#=========================================================================================>
# Specification without an excluded instrument: Note; this is infeasible in the conventional
# IV set-up.
MMDIV_4<- imlmreg2.fit(Y=IV_4.2$y,X=as.matrix(IV_4.2$x$regressors[,-1]),
                        Z = as.matrix(IV_4.2$x$instruments[,-c(1,2)]))
#------------------------------------------
# specification testing
MMDIV_4_SU=speclmb.test(reg.Obj = MMDIV_4,B=B,cl=5)
#------------------------------------------
# relevance testing
MMDIV_4_rel.Obj=imlmreg2.fit(IV_4.2$x$regressors[,2],IV_4.2$x$regressors[,-c(1,2)],
                             IV_4.2$x$instruments[,-c(1,2)])
MMDIV_4_rel=speclmb.test(reg.Obj = MMDIV_4_rel.Obj,B=B,cl=5)
#=========================================================================================>

# presentation of results:
# coefficients and standard errors
res.coef=cbind(MMDIV_1$coefficients,OLS_4.1$coefficients,
      MMDIV_2$coefficients,IV_4.2$coefficients,
      MMDIV_3$coefficients,IV_4.3$coefficients,
      MMDIV_4$coefficients)[c(2,3,4,5),]

res.ste=cbind(MMDIV_1$HC_Std.Err,OLS_4.1$HC_Std.Err,
              MMDIV_2$HC_Std.Err,IV_4.2$HC_Std.Err,
              MMDIV_3$HC_Std.Err,IV_4.3$HC_Std.Err,
              MMDIV_4$HC_Std.Err)[c(2,3,4,5),]

#round values to three decimal places
res.coef=round(res.coef,3); res.ste=round(res.ste,3)

rownames(res.coef)=c("% Huguenots.coef","ln workers.coef","ln looms.coef",
                     "ln materials.coef")
rownames(res.ste)=c("% Huguenots.ste","ln workers.ste","ln looms.ste",
                    "ln materials.ste")

resCS=rbind(res.coef,res.ste)[c(1,5,2,6,3,7,4,8),]
colnames(resCS)=c("MMD1","OLS1","MMD2","IV2","MMD3","IV3","MMD4")
resCS

#                    MMD1  OLS1  MMD2   IV2  MMD3   IV3  MMD4
# % Huguenots.coef  1.823 1.741 1.935 3.475 1.928 3.380 1.816
# % Huguenots.ste   0.797 0.471 0.888 0.960 0.869 0.990 0.806
# ln workers.coef   0.130 0.123 0.128 0.135 0.128 0.134 0.130
# ln workers.ste    0.045 0.034 0.044 0.034 0.044 0.034 0.045
# ln looms.coef     0.086 0.102 0.086 0.082 0.086 0.083 0.087
# ln looms.ste      0.041 0.036 0.042 0.036 0.041 0.036 0.041
# ln materials.coef 0.802 0.800 0.803 0.811 0.803 0.811 0.801
# ln materials.ste  0.034 0.030 0.033 0.031 0.033 0.031 0.034

# for pasting into TeX
apply(resCS,1,paste,collapse=" & ")

# % Huguenots.coef 
# "1.823 & 1.741 & 1.935 & 3.475 & 1.928 & 3.38 & 1.816\\
# % Huguenots.ste 
# "0.797 & 0.471 & 0.888 & 0.96 & 0.869 & 0.99 & 0.806\\
# ln workers.coef 
# "0.13 & 0.123 & 0.128 & 0.135 & 0.128 & 0.134 & 0.13\\
# ln workers.ste 
# "0.045 & 0.034 & 0.044 & 0.034 & 0.044 & 0.034 & 0.045\\ 
# ln looms.coef 
# "0.086 & 0.102 & 0.086 & 0.082 & 0.086 & 0.083 & 0.087\\
# ln looms.ste 
# "0.041 & 0.036 & 0.042 & 0.036 & 0.041 & 0.036 & 0.041\\
# ln materials.coef 
# "0.802 & 0.8 & 0.803 & 0.811 & 0.803 & 0.811 & 0.801\\
# ln materials.ste 
# "0.034 & 0.03 & 0.033 & 0.031 & 0.033 & 0.031 & 0.034\\

# MMD relevance tests
paste(round(c(NA,NA,MMDIV_2_rel$p.value,NA,MMDIV_3_rel$p.value,
  NA,MMDIV_4_rel$p.value),3),collapse = " & ")

# NA & NA & 0.001 & NA & 0.002 & NA & 0.084 \\

# Su & Zheng's specification tests

paste(round(c(MMDIV_1_SU$p.value,OLS_4.1_SU$p.value,MMDIV_2_SU$p.value,IV_4.2_SU$p.value,
  MMDIV_3_SU$p.value,IV_4.3_SU$p.value,MMDIV_4_SU$p.value),3),collapse = " & ")
# 0.3 & 0.49 & 0.327 & 0.296 & 0.317 & 0.34 & 0.3\\
#=========================================================================================>