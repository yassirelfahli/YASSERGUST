#================================================================================>

# Gerstner-Tsyawo 2019
# PISA Panel analysis 
# Construct Dataset
# Updated: 1/18/2021

# ================================================================>

## Install and load packages
library(intsvy)
library(dplyr)
library(readr)
library(SAScii)
library(ggplot2)

# Set working directory path to source file (all files should be located in the same folder)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 

# ================================================================>

# Load datasets

PISA2009 <- read.csv("PISA2009.csv")
PISA2009$TIME <- rep(1,nrow(PISA2009))
PISA2012 <- read.csv("PISA2012.csv")
PISA2012$TIME <- rep(2,nrow(PISA2012))
PISA2015 <- read.csv("PISA2015.csv")
PISA2015$TIME <- rep(3,nrow(PISA2015))

# ================================================================>

# Add other variables
Incomeall = read.csv("OECDIncCat.csv") 
names(Incomeall) = c("CNT","INC2009","INC2012","INC2015")
GDPall = read.csv("GDPpercap.csv") 
names(GDPall) = c("CNT","GDP2008","GDP2011","GDP2014")
Countrydat = read.csv("geo_cepii.csv")
Countrydat$CNT = Countrydat$�..CNT

# Choose list of countries
temp1 = merge(PISA2009,PISA2012, by = "CNT")
dim(temp1)
temp2 = merge(temp1,PISA2015, by = "CNT")
dim(temp2)
head(temp2)

CNTselect = unique(temp2$CNT)

# Subset datasets by country list
PISA2009select=PISA2009[PISA2009$CNT%in%CNTselect,]
PISA2012select=PISA2012[PISA2012$CNT%in%CNTselect,]
PISA2015select=PISA2015[PISA2015$CNT%in%CNTselect,]
Incomeselect=Incomeall[Incomeall$CNT%in%CNTselect,]
GDPselect=GDPall[GDPall$CNT%in%CNTselect,]
Countryselect=Countrydat[Countrydat$CNT%in%CNTselect,]

# Add columns with additional variables
# Income categories in 2015
PISA2009select$INCOME = Incomeselect$INC2015
PISA2012select$INCOME = Incomeselect$INC2015
PISA2015select$INCOME = Incomeselect$INC2015

# GDP lagged by one year
PISA2009select$GDP = GDPselect$GDP2008
PISA2012select$GDP = GDPselect$GDP2011
PISA2015select$GDP = GDPselect$GDP2014

# OECD membership in 2015
PISA2009select$OECD = Countryselect$OECD
PISA2012select$OECD = Countryselect$OECD
PISA2015select$OECD = Countryselect$OECD

# Continent
PISA2009select$Continent = Countryselect$continent
PISA2012select$Continent = Countryselect$continent
PISA2015select$Continent = Countryselect$continent

# ================================================================>

# Merge datasets
Datall = rbind(PISA2009select,PISA2012select,PISA2015select)
dim(Datall)
names(Datall)

#write.csv(Datall, "Gerstner_Tsyawo_2022_Data.csv",row.names=FALSE)