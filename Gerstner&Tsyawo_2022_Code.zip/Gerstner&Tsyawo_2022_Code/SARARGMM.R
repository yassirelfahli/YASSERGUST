#================================================================================>

#Author: Emmanuel Selorm Tsyawo & Clara-Christina Gerstner
#Place: Philadelphia
#Date: Feb. 14, 2020
#Last Update: January 1, 2021
#Comment: Code for executing a higher order SARAR(p,q) and SAR(p) using GMM of
#Lee & Liu 2010

#================================================================================>

# SARAR GMM function
# Arguments: theta - parameter vector of (rho,lambda,beta)
#           Y - nx1 vector of dependent variable
#           X - nxkb matrix of independent variables
#           W - should be a list of p weight matrices in the conditional and autoregressive errors

SRBGMM<- function(theta,Y,X,W,res="gsq",M=NULL){
  if(!is.list(W)){stop("W should be a list of matrices")}
  p = length(W)
  X = as.matrix(X); kb = ncol(X); n = nrow(X); Y = matrix(Y,ncol = 1)
  
  if(length(theta)!=(2*p+kb+1)){stop("length of theta should match 2p+kb+1")}
  
  rho = theta[1:p]; lam = theta[(p+1):(2*p)]; bet = matrix(theta[-c(1:(2*p))],ncol = 1)
  Wr = Ml =  matrix(0,n,n); In = diag(n)
  P =  cbind(1,X)
  
  for (j in 1:p) {
    Wr=Wr+rho[j]*W[[j]]
    Ml=Ml+lam[j]*W[[j]]
    P = cbind(P,W[[j]]%*%X)
  }
  q = ncol(P)
  Ml=In-Ml; Wr=In-Wr 
  
  eps = Ml%*%(Wr%*%Y-cbind(1,X)%*%bet) #vector of errors
  
  for (j in 1:p) {
    P = cbind(P,W[[j]]%*%eps)  
  } # complete the matrix of instruments
 # P=P[,which(abs(eigen(t(P)%*%P)$values)>=1e-5)] #weed out perfectly correlated instruments
  if(ncol(P)<(ncol(X)+1)){stop("Not enough linearly independent instruments.")}
  ncP = ncol(P)
  gn = c(t(P)%*%eps)
  
  if(res=="gsq"){ ans = sum(gn*gn)}
  else if(res=="gn"){ans = gn}
  else if(res=="gMg"){if(is.null(M)){M=diag(ncP)}; ans = t(gn)%*%M%*%gn/n}
  else if(res=="Ms"){for(j in 1:ncP){P[,j]=P[,j]*eps};ans = cov(P)*n}
  else if(res=="Ma"){sig2 = mean(eps^2); V11 = sig2*t(P[,1:q])%*%P[,1:q]; V22=matrix(0,p,p)
    for(j in 1:p){for(i in 1:j){V22[i,j]=sum(diag(0.5*(W[[i]]+t(W[[i]]))%*%W[[j]]));V22[j,i]=V22[i,j]}}
    ans = as.matrix(Matrix::bdiag(V11,V22))  
  }else{stop("Type of output not recognised; res must be gsq, gMg,or M")}
  return(ans)
}

#================================================================================>

# SARAR GMM Output
# Arguments: theta - parameter vector of (rho,lambda,beta)
#           Y - nx1 vector of dependent variable
#           X - nxkb matrix of independent variables
#           W - should be a list of p weight matrices in the conditional and autoregressive errors

rgSRBGMM<- function(theta0,Y,X,W){
  obj=optim(par = theta0,fn=SRBGMM,Y=Y,X=X,W=W)
  Mws2=SRBGMM(theta=obj$par,Y=Y,X=X,W=W,res = "Ms")
  obj2=optim(par = theta0,fn=SRBGMM,res = "gMg",M=solve(Mws2),Y=Y,X=X,W=W)
  coefs=obj2$par
  Dn = pracma::jacobian(f=SRBGMM,x0 = coefs,res = "gn",Y=Y,X=X,W=W)
  Omega=SRBGMM(theta=coefs,Y=Y,X=X,W=W,res = "Ms")
  VC = solve(t(Dn)%*%solve(Omega)%*%Dn)
  J = obj2$value*length(Y) #compute J-statistic
  df1 <- ncol(Omega)-length(coefs) # degrees of freedom
  p1 <- 1 - pchisq(q=J,df=df1) # p-Value
  list(coefs=coefs,VC=VC,obj=obj2,Jstat=J,pvalJ=p1,df=df1)
}

#================================================================================>

# SAR GMM function
# Arguments: theta - parameter vector of (rho,beta)
#           Y - nx1 vector of dependent variable
#           X - nxkb matrix of independent variables
#           W - should be a list of p weight matrices in the conditional and autoregressive errors

SARGMM<- function(theta,Y,X,W,res="gsq",M=NULL,cluster=NULL){
  if(!is.list(W)){stop("W should be a list of matrices")}
  p = length(W)
  X = as.matrix(X); kb = ncol(X); n = nrow(X); Y = matrix(Y,ncol = 1)
  
  if(length(theta)!=(p+kb+1)){stop("length of theta should match p+kb+1")}
  
  rho = theta[1:p]; bet = matrix(theta[-c(1:p)],ncol = 1)
  Wr = matrix(0,n,n); In = diag(n)
  P =  cbind(1,X)
  
  for (j in 1:p) {
    Wr=Wr+rho[j]*W[[j]]
    P = cbind(P,W[[j]]%*%X)
  }
  q = ncol(P)
  Wr=In-Wr 
  
  eps = Wr%*%Y-cbind(1,X)%*%bet #vector of errors
  
  # for (j in 1:p) {
  #   P = cbind(P,W[[j]]%*%eps)  
  # } # complete the matrix of instruments
  P=P[,which(abs(eigen(crossprod(P))$values)>=1e-5)] #weed out perfectly correlated instruments
  if(ncol(P)<(ncol(X)+1)){stop("Not enough linearly independent instruments.")}

  ncP = ncol(P)
  gn = c(t(P)%*%eps)
  
  if(res=="gsq"){ ans = sum(gn*gn)}
  else if(res=="gn"){ans = gn}
  else if(res=="gMg"){if(is.null(M)){M=diag(ncP)}; ans = t(gn)%*%M%*%gn/n}
  else if(res=="Ms"){for(j in 1:ncP){P[,j]=P[,j]*eps};
    if(is.null(cluster)){ans = cov(P)*n}else{
      uclus = unique(cluster); luC = length(uclus); PP = matrix(NA,luC,ncol(P))
      for (i in 1:luC) { PP[i,] = apply(P[which(cluster==uclus[i]),],2,sum)}
      ans = cov(PP)*luC} #end if is.null(cluster)
    }# end if(res=="Ms)
  else{stop("Type of output not recognised; res must be gsq, gMg,or M")}
  return(ans)
}

#================================================================================>
# Conducts differencing of data to eliminate fixed effects
# Arguments:  dat - the nxp data frame
#             cluster - a vector of length n with ids along which to difference 
#             fixed effects
procdat<- function(dat,cluster){
  newdat=dat
  uclus = unique(cluster)
  for (j in 1:ncol(newdat)) {
    for (l in 1:length(uclus)) {#demean data by cluster
      newdat[which(cluster==uclus[l]),j]=newdat[which(cluster==uclus[l]),j]-mean(newdat[which(cluster==uclus[l]),j])
    }#end for l
  }#end for j
  newdat
}



#================================================================================>
# SAR GMM Output
# Arguments: theta - parameter vector of (rho,beta)
#           Y - nx1 vector of dependent variable
#           X - nxkb matrix of independent variables
#           W - should be a list of p weight matrices in the conditional and autoregressive errors

rgSARGMM<- function(theta0,Y,X,W,cluster=NULL){
  obj=optim(par = theta0,fn=SARGMM,Y=Y,X=X,W=W) #run first-stage un-weighted GMM
  Mws2=SARGMM(theta=obj$par,Y=Y,X=X,W=W,res = "Ms",cluster=cluster) #obtain weight matrix
  obj2=optim(par = theta0,fn=SARGMM,res = "gMg",M=solve(Mws2, tol=.Machine$double.eps^2),Y=Y,X=X,W=W)#weighted GMM
  coefs=obj2$par
  Dn = pracma::jacobian(f=SARGMM,x0 = coefs,res = "gn",Y=Y,X=X,W=W)
  Omega=SARGMM(theta=coefs,Y=Y,X=X,W=W,res = "Ms",cluster=cluster)
  VC = solve(t(Dn)%*%solve(Omega)%*%Dn, tol=.Machine$double.eps^2); VC = 0.5*(t(VC) + VC)
  J = obj2$value*length(Y) #compute J-statistic
  df1 <- ncol(Omega)-length(coefs) # degrees of freedom
  p1 <- 1 - pchisq(q=J,df=df1) # p-Value
  eps = Y-cbind(1,as.matrix(X))%*%coefs[-1] #vector of errors
  R2 <- 1- (var(eps)/var(Y))# R^2 value
  list(coefs=coefs,VC=VC,obj=obj2,Jstat=J,pvalJ=p1,df=df1, R2=as.numeric(R2))
}

#================================================================================>

# SAR GMM function with time-varying rho, this is suitable for short T, large N
# Arguments: theta - parameter vector of (rho,beta)
#           Y - nx1 vector of dependent variable
#           X - nxkb matrix of independent variables
#           W - should be a list of p weight matrices in the conditional and autoregressive errors

SARGMMT<- function(theta,Y,X,W,tvar,res="gsq",M=NULL){
  if(!is.list(W)){stop("W should be a list of matrices")}
  X = as.matrix(X); kb = ncol(X); N = nrow(W[[1]]); Y = matrix(Y,ncol = 1); 
  t = length(unique(tvar)); n = N*t
  
  
  if(length(theta)!=(t+kb+1)){stop("length of theta should match t+kb+1")}
  
  rho = theta[1:t]; bet = matrix(theta[-c(1:t)],ncol = 1)
  In = diag(n)
  P =  cbind(1,X)
  
  Wr = kronecker(diag(t),W[[1]]) #full spatial matrix for panel
  Wr2 = kronecker(diag(rho),W[[1]]) #spatial matrix times vector of time-varying rho
  P = cbind(P,Wr%*%X)
  
  #q = ncol(P)
  Wr2=In-Wr2 
  
  eps = Wr2%*%Y-cbind(1,X)%*%bet #vector of errors
  
  P = cbind(P,Wr%*%eps)  
  ncP = ncol(P)
  gn = c(t(P)%*%eps)
  
  if(res=="gsq"){ ans = sum(gn*gn)}
  else if(res=="gn"){ans = gn}
  else if(res=="gMg"){if(is.null(M)){M=diag(ncP)}; ans = t(gn)%*%M%*%gn/n}
  else if(res=="Ms"){for(j in 1:ncP){P[,j]=P[,j]*eps};ans = cov(P)*n}
  # else if(res=="Ma"){sig2 = mean(eps^2); V11 = sig2*t(P[,1:q])%*%P[,1:q]; V22=matrix(0,p,p)
  #   for(j in 1:p){for(i in 1:j){V22[i,j]=sum(diag(0.5*(W[[i]]+t(W[[i]]))%*%W[[j]]));V22[j,i]=V22[i,j]}}
  #   ans = as.matrix(Matrix::bdiag(V11,V22))  
  # }
  else{stop("Type of output not recognised; res must be gsq, gMg,or M")}
  return(ans)
}

#================================================================================>

# SAR GMM Output with time-varying rho
# Arguments: theta - parameter vector of (rho,beta)
#           Y - nx1 vector of dependent variable
#           X - nxkb matrix of independent variables
#           W - should be a list of p weight matrices in the conditional and autoregressive errors

rgSARGMMT<- function(theta0,Y,X,tvar,W){
  obj=optim(par = theta0,fn=SARGMMT,Y=Y,X=X,tvar=tvar,W=W)
  Mws2=SARGMMT(theta=obj$par,Y=Y,X=X,tvar=tvar,W=W,res = "Ms")
  obj2=optim(par = theta0,fn=SARGMMT,res = "gMg",M=solve(Mws2),Y=Y,X=X,tvar=tvar,W=W)
  coefs=obj2$par
  Dn = pracma::jacobian(f=SARGMMT,x0 = coefs,res = "gn",Y=Y,X=X,tvar=tvar,W=W)
  Omega=SARGMMT(theta=coefs,Y=Y,X=X,tvar=tvar,W=W,res = "Ms")
  VC = solve(t(Dn)%*%solve(Omega)%*%Dn)
  J = obj2$value*length(Y) #compute J-statistic
  df1 <- ncol(Omega)-length(coefs) # degrees of freedom
  p1 <- 1 - pchisq(q=J,df=df1) # p-Value
  list(coefs=coefs,VC=VC,obj=obj2,Jstat=J,pvalJ=p1,df=df1)
}
