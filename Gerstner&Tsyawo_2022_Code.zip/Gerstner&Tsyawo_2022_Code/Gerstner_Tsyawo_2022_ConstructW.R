#================================================================================>

# Gerstner-Tsyawo 2019
# PISA Panel analysis 
# Construct Spatial matrices
# Updated: 1/18/2021

# ================================================================>

library(car)
library(raster)
library(spdep)

# Set working directory path to source file (all files should be located in the same folder)
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 

# Load data
Dat_Final <- read.csv("Gerstner_Tsyawo_2022_Data.csv")

zt <- max(unique(Dat_Final$TIME)); N = length(unique(Dat_Final$CNT)); Nt = N*zt

# ================================================================>

### Geographic distance = W1 ###
Dat_Final2 = Dat_Final[1:N,]
countries <- unique(Dat_Final2$CNT)
length(countries)

Geo_distances <- read.csv("geo_cepii.csv")
Geo_dat = Geo_distances[Geo_distances$�..CNT%in%countries,]
pts <- Geo_dat[,12:11]
CountryID <- Geo_dat[,1]

Dis <- pointDistance(pts, lonlat = TRUE)
colnames(Dis) <- CountryID
rownames(Dis) <- CountryID

# Define spatial weight matrix W
# Inverse distance matrix
Dis[which(is.na(Dis))] <- 0
Dis_Full <- Dis + t(Dis)
for(i in 1:dim(Dis_Full)[1]) {Dis_Full[i,i] = 0} # renders exactly zero all diagonal elements
Dis_Full_Inv <- ifelse(Dis_Full!=0, 1/Dis_Full, Dis_Full)    # inverting distances

# Create matrix for Panel data for 3 time periods
Dis_Full_Inv_P=kronecker(diag(zt), Dis_Full_Inv)
Dis_Full_Inv_P=Dis_Full_Inv_P/apply(Dis_Full_Inv_P, 1, sum)
W1 <- Dis_Full_Inv_P
min(abs(eigen(W1)$values))
dim(W1)

#write.csv(W1, "GeoW.csv", row.names = F)

# ================================================================>

### European countries only = W1b ###
countries2 <- unique(Dat_Final2[Dat_Final2$Continent=='Europe',]$CNT)
length(countries2)

Geo_distances <- read.csv("geo_cepii.csv")
Geo_dat = Geo_distances[Geo_distances$�..CNT%in%countries2,]
pts <- Geo_dat[,12:11]
CountryID <- Geo_dat[,1]

Dis <- pointDistance(pts, lonlat = TRUE)
colnames(Dis) <- CountryID
rownames(Dis) <- CountryID

# Define spatial weight matrix W
# Inverse distance matrix
Dis[which(is.na(Dis))] <- 0
Dis_Full <- Dis + t(Dis)
for(i in 1:dim(Dis_Full)[1]) {Dis_Full[i,i] = 0} # renders exactly zero all diagonal elements
Dis_Full_Inv <- ifelse(Dis_Full!=0, 1/Dis_Full, Dis_Full)    # inverting distances

# Create matrix for Panel data for 3 time periods for subgroups
Dis_Full_Inv_P=kronecker(diag(zt), Dis_Full_Inv)
Dis_Full_Inv_P=Dis_Full_Inv_P/apply(Dis_Full_Inv_P, 1, sum)
W1b <- Dis_Full_Inv_P
min(abs(eigen(W1b)$values))
dim(W1b)

#write.csv(W1b, "GeoW_EU.csv", row.names = F)

# ================================================================>

### OECD countries only = W1c ###
countries3 <- unique(Dat_Final2[Dat_Final2$OECD==1,]$CNT)
length(countries3)

Geo_distances <- read.csv("geo_cepii.csv")
Geo_dat = Geo_distances[Geo_distances$�..CNT%in%countries3,]
pts <- Geo_dat[,12:11]
CountryID <- Geo_dat[,1]

Dis <- pointDistance(pts, lonlat = TRUE)
colnames(Dis) <- CountryID
rownames(Dis) <- CountryID

# Define spatial weight matrix W
# Inverse distance matrix
Dis[which(is.na(Dis))] <- 0
Dis_Full <- Dis + t(Dis)
for(i in 1:dim(Dis_Full)[1]) {Dis_Full[i,i] = 0} # renders exactly zero all diagonal elements
Dis_Full_Inv <- ifelse(Dis_Full!=0, 1/Dis_Full, Dis_Full)    # inverting distances

# Create matrix for Panel data for 3 time periods for subgroups
Dis_Full_Inv_P=kronecker(diag(zt), Dis_Full_Inv)
Dis_Full_Inv_P=Dis_Full_Inv_P/apply(Dis_Full_Inv_P, 1, sum)
W1c <- Dis_Full_Inv_P
min(abs(eigen(W1c)$values))
dim(W1c)

#write.csv(W1c, "GeoW_OECD.csv", row.names = F)

# ================================================================>

### Without ISR and SWE = W1d ###
countries4 <- unique(Dat_Final2[!Dat_Final2$CNT==c("SWE","ISR"),]$CNT)
length(countries4)

Geo_distances <- read.csv("geo_cepii.csv")
Geo_dat = Geo_distances[Geo_distances$�..CNT%in%countries4,]
pts <- Geo_dat[,12:11]
CountryID <- Geo_dat[,1]

Dis <- pointDistance(pts, lonlat = TRUE)
colnames(Dis) <- CountryID
rownames(Dis) <- CountryID

# Define spatial weight matrix W
# Inverse distance matrix
Dis[which(is.na(Dis))] <- 0
Dis_Full <- Dis + t(Dis)
for(i in 1:dim(Dis_Full)[1]) {Dis_Full[i,i] = 0} # renders exactly zero all diagonal elements
Dis_Full_Inv <- ifelse(Dis_Full!=0, 1/Dis_Full, Dis_Full)    # inverting distances

# Create matrix for Panel data for 3 time periods for subgroups
Dis_Full_Inv_P=kronecker(diag(zt), Dis_Full_Inv)
Dis_Full_Inv_P=Dis_Full_Inv_P/apply(Dis_Full_Inv_P, 1, sum)
W1d <- Dis_Full_Inv_P
min(abs(eigen(W1d)$values))
dim(W1d)

#write.csv(W1d, "GeoW_NA.csv", row.names = F)