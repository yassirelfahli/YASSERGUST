#================================================================================>
#Author: Emmanuel Selorm Tsyawo & Clara-Christina Gerstner
#Place: Philadelphia
#Spatial analysis Functions
#Updated: 5/1/2020
# ================================================================>

# Starting values for SAR(AR) model
# Arguments: X - matrix of independent variables
#           Y - vector of dependent variables
#           W - list of p weight matrices

Start_values <- function(X,Y,W,mod="SAR"){
  p = length(W)
  X = as.matrix(X); 
  if(any(abs(eigen(t(X)%*%X)$values)<1e-5)){stop("X is possibly not full rank")}
  kb = ncol(X); n = nrow(X); Y = matrix(Y,ncol = 1)
  
  P = W[[1]]%*%Y
  Q = W[[1]]%*%X[,-1]
  
  if(p>1){
  for (j in 2:p) {
    P = cbind(P,W[[j]]%*%Y)
    Q = cbind(Q,W[[j]]%*%X[,-1])
    }
  }
  
  D = cbind(X[,1],P,X[,-1]) #design matrix; constant term, w*y's, X 
  E = cbind(X,Q) #matrix of instruments X and spatially lagged X
  E = E[,which(abs(eigen(t(E)%*%E)$values)>1e-5)]#only linearly independent instruments
  
  if(ncol(E)<ncol(D)){stop("Not enough instruments with independent variation.")}
  
  A = (t(D)%*%E)%*%solve(t(E)%*%E)%*%(t(E)%*%D)
  b = (t(D)%*%E)%*%solve(t(E)%*%E)%*%(t(E)%*%Y)
    
  BW <- solve(A,b) #compute two-stage least squares, Ref: Wooldridge(2009) eqn.5.22
  
  # obtain vector of names
  r <- replicate(p,"rho")
  l <- replicate(p,"lambda")
  namenSARAR <- c(r,l,rownames(BW)[-c(1:(p+1))])
  namenSAR <- c(r,rownames(BW)[-c(1:(p+1))])
  
  # obtain degrees of freedom
  df1 = ncol(E)

  # SARAR starting values
  SVsarar <- c(BW[2:(p+1)],BW[2:(p+1)],BW[1],BW[-c(1:(p+1))])
  
  # SAR starting values
  BWsar <- rep(0,(p+1))
  for (j in 2:(p+1)) {
  BWsar[j] <-  c(BW[j])
  }
  SVsar <- c(BWsar[2:(p+1)],BW[1],BW[-c(1:(p+1))])
  
  # print output
  if(mod=="SARAR"){
    list(SV=SVsarar, name=namenSARAR, degree=df1)
  }
  else if(mod=="SAR"){
    list(SV=SVsar, name=namenSAR, degree=df1)
  }
}

# ================================================================>

# Obtain output of estimates for SAR and SARAR model
# Arguments: SO - spatial object obtained from rgSRBGMM and rgSARGMM
#           nam - vector of variable names obtained from staring_values function
#           W - list of p weight matrices

Spatial_output <- function(SO, nam ,W , mod="SAR"){
  p=length(W)
  
  # Estimates  
  Est = SO$coefs
  # standard error
  SE = sqrt(diag(SO$VC))
  # z-values
  z = SO$coefs/sqrt(diag(SO$VC))
  
  Out = cbind(Est,SE,z)
  
  if(mod=="SARAR"){
    Outcut <- Out[-((2*p)+1),]
    rownames(Outcut) <- nam
    return(Outcut)
  }
  
  if(mod=="SAR"){
    Outcut <- Out[-(p+1),]
    rownames(Outcut) <- nam
    return(Outcut)
  }
  
  if(mod=="SARART"){
    Outcut <- Out[-((2*p)+1),]
    rownames(Outcut) <- nam
    return(Outcut)
  }

  else if(mod=="SART"){
    Outcut <- Out[-(4*p+1),]
    rownames(Outcut) <- nam
    return(Outcut)
  }
}

# ================================================================>

# Summary measures (direct, indirect, total effects) for SAR model
# Arguments: b - vector of estimates
#           rho - vector of rhos
#           W - list of weight matrices

Sum_spatial <- function(b,rho,W){
  a = length(b)
  n = ncol(W[[1]])
  p = length(W)
  I_n = diag(n)
  
  for (j in 1:p) {
    rW <- rho[j] * W[[j]]
  }
  VW <- solve(I_n - rW)
  
  # obtain direct and total effects
  M_direct = rep(NA,a)
  M_total = rep(NA,a)
  
  for (i in 1:a){
    SrW <- VW * b[i]
    M_direct[i] <- 1/n * sum(diag(SrW))
    M_total[i] <- (sum(c(SrW)))/n
  }
  
  # obtain indrect effects
  M_indirect <- M_total - M_direct
  
  # return answer
  ans <- c(M_total, M_direct, M_indirect)
  return(ans)
}

# ================================================================>

# Obtain weight matrix for nominal or ordinal vector of attributes
# Arguments: A - data vector for weights

weight_fx <- function(A){

W = matrix(0,length(A), length(A))

for (i in 2:length(A)) {
  for (j in 1:(i-1)) {
    if(A[i]==A[j]) {W[i,j]=1;W[j,i]=W[i,j]}
  }
}

W=W/apply(W,1,sum)
return(W)
}