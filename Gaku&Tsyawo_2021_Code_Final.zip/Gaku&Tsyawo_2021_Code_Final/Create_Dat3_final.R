#----------------------------------------------------------------------------------
# load data:

dat<- read.csv("c_glss612_final.csv",header = TRUE)
# Notes on data:
# clust - enumeration area; nh - house number; s1q5y - age
# HHSIZE - Household size; ez - ecological zone
#----------------------------------------------------------------------------------

# keep communities with more than one observation
idk=names(table(dat$clust))[which(table(dat$clust)>1)]
datk=dat[which(dat$clust %in% idk),]
datk=datk[which(complete.cases(datk)),]
(nr=dim(datk)[1]) # [1] 21205
dim(dat)[1]-dim(datk)[1] # [1] 4 isolated observations dropped

# Construct the spatial matrix
W = matrix(0,nr,nr)
summary(dat$clust) #all clust observed.
length(unique(dat$clust))#[1] 1196 unique clusters

for (l in 1:length(idk)) {
  idl=which(datk$clust==idk[l])
  W[idl,idl]=1; diag(W[idl,idl])=0 #zero diagonal elements
}

# row-normalise the spatial matrix
W.raw = W #this form needed for subsetting before row-normalisation
size.net = apply(W,1,sum)
summary(size.net+1) #recall add the diagonal element
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 2.0    15.0    21.0    21.8    27.0    66.0
W = W/size.net

#----------------------------------------------------------------------------------
datk$EcZone<- datk$ez
# Add Greater Accra Metropolitan Area to the Coastal Zone
datk$EcZone[which(datk$EcZone=="GAMA")]<- "Coastal" 
#----------------------------------------------------------------------------------
# Construct Community-level employment rate using indicator of whether the household head works
# datk$Com_Emp=datk$hwrk; uclusk = unique(datk$clust)
# for(l in 1:length(uclusk)){
#   idclus=which(datk$clust==uclusk[l])
#   datk$Com_Emp[idclus]=mean(datk$hwrk[idclus]) #compute community-level unemployment rate
# }


