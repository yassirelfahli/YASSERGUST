#rm(list = ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 
#set directory to source file
list.files()
library(spatialreg)
library(spdep)
#sourcing files for data and functions - takes a bit of time
source("Create_Dat3_final1.R")
source("Funciones.R")
#----------------------------------------------------------------------------------
names(datk)
#-------------------------------------------
# Function to run sub-samples
# Arguments:  var.sub - the discrete variable along which sub-samples are created
#             formula - the formula to run on the sub-sample; defaults to fml.1
# This function only prints out output

ssregs=function(var.sub,formula=fml.1){
  u.var = unique(var.sub)
  for (l in 1:length(u.var)) {
    cat("Sub-sample is ",u.var[l]," \n")
    id = which(var.sub==u.var[l])
    Modl = regf2(formula = formula,subsamp = id) #use sub-sample
    summary.g2sls(Modl,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
    cat(rep("=",45)); cat("\n")
  }#end for l
}

#=====================================================================================>
#********* Begin Printing out output to file
Out_log <- file("Out_log3_final1.txt") # File name of output log

sink(Out_log, append = TRUE, type = "output") # Writing console output to log file
sink(Out_log, append = TRUE, type = "message")

cat(readChar(rstudioapi::getSourceEditorContext()$path, # Writing currently opened R script to file
             file.info(rstudioapi::getSourceEditorContext()$path)$size))
#=====================================================================================>



#----------------------------------------------------------------------------------
cat("\n")
cat("Full Sample - Results","\n")
fml.1 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+
                         hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+
                         trd+as.factor(EcZone)+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))
Mod.1 = regf2(formula = fml.1) #use full sample
summary.g2sls(Mod.1,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude religious dummies
cat("\n")
cat("Full Sample - Results with religious dummies excluded","\n")
fml.2 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+
                         hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+
                         as.factor(EcZone)+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))
Mod.2 = regf2(formula = fml.2) #use full sample
summary.g2sls(Mod.2,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude household characteristics
cat("\n")
cat("Full Sample - Results with household characteristics excluded","\n")
fml.3 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+chr+mos+
                         trd+as.factor(EcZone)+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))
Mod.3 = regf2(formula = fml.3) #use full sample
summary.g2sls(Mod.3,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude Ecological Zone dummies
cat("\n")
cat("Full Sample - Results with Ecological Zone dummies excluded","\n")
fml.4 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+
                         hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))
Mod.4 = regf2(formula = fml.4) #use full sample
summary.g2sls(Mod.4,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude Regional dummies
cat("\n")
cat("Full Sample - Results with Regional dummies excluded","\n")
fml.5 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+
                         hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)+as.factor(mdate)*as.factor(ydate)"))
Mod.5 = regf2(formula = fml.5) #use full sample
summary.g2sls(Mod.5,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude age and age squared
cat("\n")
cat("Full Sample - Results with age variables excluded","\n")
fml.8 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))
Mod.8 = regf2(formula = fml.8) #use full sample
summary.g2sls(Mod.8,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Include Month x Rural interaction
cat("\n")
cat("Full Sample - Results with age variables excluded","\n")
fml.9 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+
                         hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+
                         trd+as.factor(EcZone)+as.factor(region)+as.factor(mdate)*as.factor(rural1)"))
Mod.9 = regf2(formula = fml.9) #use full sample
summary.g2sls(Mod.9,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
#Test of the impact of seasonality on Child labour in rural and urban areas
aod::wald.test(Sigma = Mod.9$vcovHC,b=Mod.9$coefficients,Terms = 43:52)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------



#----------------------------------------------------------------------------------
# Formulae for sub-groups to study - Ecological Zones, Sex, Rural/Urban, Regions
fml.EcZone = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))
fml.sex = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+
                           trd+as.factor(EcZone)+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))
fml.rural = as.formula(paste("wrk~pv2+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+
                             trd+as.factor(EcZone)+as.factor(region)+as.factor(mdate)*as.factor(ydate)"))

# ------------- Ecological Zones ------------- 
cat("\n")
cat("Sub Sample Results by Ecological Zone","\n")
ssregs(var.sub=datk$EcZone,formula=fml.EcZone)

# ------------- Sex ------------- 
cat("\n")
cat("Sub Sample Results by Sex","\n")
ssregs(var.sub=datk$sex,formula=fml.sex)

# ------------- Rural/Urban ------------- 
cat("\n")
cat("Sub Sample Results by Rural/Urban (1/0)","\n")
ssregs(var.sub=datk$rural1,formula=fml.rural)
#----------------------------------------------------------------------------------


#=====================================================================================>
# Closing Log File
closeAllConnections() # Close connection to log file
#=====================================================================================>
