# **** Functions to Use in Code
#-------------------------------------------
# function to run generalised two-stage least squares
g2sls<- function(formula,data=list(),W.m,Residuals=NULL){
  mt <- terms(formula, data = data)
  mf <- lm(formula, data, method = "model.frame")
  y <- model.extract(mf, "response")
  X <- model.matrix(mt, mf)
  W.my = W.m%*%c(y); colnames(W.my) <- c("Rho"); xcolnames <- colnames(X)
  # First Stage to obtain residuals; 
  # Eliminate linearly dependent columns in instruments and design matrix
  Koef.1 = coef(lm(rep(1,length(y))~as.matrix(cbind(X[,-1],W.m%*%X[,-1]))))
  Koef.2 = coef(lm(rep(1,length(y))~as.matrix(cbind(W.my,X[,-1]))))
  Z=cbind(1,X[,-1],W.m%*%X[,-1])[,which(!is.na(Koef.1))]
  xcolnames=xcolnames[which(!is.na(Koef.2[-2]))]
  R=cbind(1,W.my,X[,-1])[,which(!is.na(Koef.2))]
  F.S = AER::ivreg(y~as.matrix(R[,-1])|as.matrix(Z[,-1]))
  if(is.null(Residuals)){e2 = abs(F.S$residuals)}else{e2=abs(Residuals)}
  e2[!is.na(e2) & e2<1e-05]=1e-05 #avoid near zeroes
  #y.F = F.S$model$y; X.F = F.S$model[[2]]; Z.F = F.S$model[[3]]
  obj=AER::ivreg(y~as.matrix(R[,-1])|as.matrix(Z[,-1]),weights = 1/e2)
  names(obj$coefficients)=c(xcolnames[1],"rho",xcolnames[-1])
  
  # R = cbind(1,F.S$model[[2]]); #Z = cbind(1,F.S$model[[3]]); 
  ZR = t(Z)%*%R
  
  obj$vcovHC = solve(t(ZR)%*%solve(t(Z)%*%diag(e2^2)%*%Z,tol=.Machine$double.eps^1.25)%*%ZR,tol=.Machine$double.eps^1.25)
  obj$SE_HC = sqrt(diag(obj$vcovHC))
  names(obj$SE_HC)=names(obj$coefficients)
  obj$tval_HC=obj$coefficients/obj$SE_HC
  obj$pvals_HC=2*(1-pnorm(abs(obj$tval_HC))); obj$W=W.m
  obj
}

#-------------------------------------------
# Arguments: 
# pars = two-element vector of [rho,beta_j] where the marginal effects are w.r.t. beta_j
marg_effect <- function(pars,W){
  rho = pars[1]; bet=pars[2]; n = nrow(W)
  SrW <- solve(diag(n) - rho*W) * bet
  M_direct <- sum(diag(SrW))/n
  M_total <- (sum(c(SrW)))/n
  # obtain indrect effects
  M_indirect <- M_total - M_direct
  # return answer
  ans <- c(M_total, M_direct, M_indirect)
  names(ans) = c("ME_total", "ME_direct", "ME_indirect")
  return(ans)
}

# Arguments:
# bet.id - the index of the parameter for which marginal effects are sought
# L - the number of simulations to be used

inference_marg_effect<- function(g2sls.obj,bet.id=3,L=2000,cl=NULL){
  p.id = c(2,bet.id) #rho is the second coefficient
  VC=g2sls.obj$vcovHC[p.id,p.id]#extract bivariate covariance matrix
  # sample from the empirical distribution of parameters
  set.seed(L)
  par.draws=MASS::mvrnorm(L,mu=coef(g2sls.obj)[p.id],Sigma = VC)
  if(ncol(par.draws)==2){par.draws=t(par.draws)} #ensure correct orientation
  
  #compute marginal effects
  marg_eff0 = marg_effect(coef(g2sls.obj)[p.id],g2sls.obj$W) 
  
  # for sampling from the empirical distribution of marginal effects
  fn = function(l) marg_effect(par.draws[,l],W=g2sls.obj$W)
  if(is.null(cl)){marg_eff.samp=sapply(1:L,fn)
  }else{marg_eff.samp=pbapply::pbsapply(1:L,fn,cl=cl)}
  
  if(ncol(marg_eff.samp)!=3){marg_eff.samp=t(marg_eff.samp)}#ensure suitable alignment
  
  # for confidence interval
  alpha = 0.1
  me_LB.1 = apply(marg_eff.samp,2,quantile,probs=alpha/2)
  me_UB.1 = apply(marg_eff.samp,2,quantile,probs=(1-alpha/2))
  alpha = 0.05
  me_LB.05 = apply(marg_eff.samp,2,quantile,probs=alpha/2)
  me_UB.05 = apply(marg_eff.samp,2,quantile,probs=(1-alpha/2))
  alpha = 0.01
  me_LB.01 = apply(marg_eff.samp,2,quantile,probs=alpha/2)
  me_UB.01 = apply(marg_eff.samp,2,quantile,probs=(1-alpha/2))
  # Inter-quartile range
  me_IQR = apply(marg_eff.samp,2,IQR)
  # Standard errors
  me_SE = apply(marg_eff.samp,2,sd)
  
  res=rbind(marg_eff0,me_LB.1,me_UB.1,me_LB.05,me_UB.05,me_LB.01,me_UB.01,me_IQR,me_SE)
  row.names(res)=c("Marginal Effects","L Conf. Int 0.1","U Conf. Int 0.1",
                   "L Conf. Int 0.05","U Conf. Int 0.05",
                   "L Conf. Int 0.01","U Conf. Int 0.01","Inter-Quartile Range","Standard Errors")
  res
}

#-------------------------------------------
# Argument:
# marg_effect - logical - report marginal effects
# other arguments are passed to inference_marg_effect()

summary.g2sls<- function(g2sls.obj,marg_effect=FALSE,bet.id=3,L=2000,cl=NULL){
  res=cbind(g2sls.obj$coefficients,g2sls.obj$SE_HC,g2sls.obj$tval_HC,g2sls.obj$pvals)
  colnames(res)=c("Estimates","Std. Error HC","t value HC","Pr(>|t|) HC")
  cat("Printing heteroskedasticity-consistent results..."," \n")
  print(res)
  
  if(marg_effect){ #if marginal effects are to be returned
    cat(" \n","Printing marginal effects..."," \n")
    print(inference_marg_effect(g2sls.obj,bet.id,L,cl))
  }
  
  cat("\n", "For goodness-of-fit measures viz. R-squared, Wald Tests.","\n")
  print(summary(g2sls.obj)); cat("\n")
  
  if(!is.null(g2sls.obj$lambda)){
    cat("\n","Lambda = ",g2sls.obj$lambda,"\n")
  }
}
#-------------------------------------------
# this function runs the regression on  a sub-sample

# Arguments:
# fml - formula that goes into stsls()
# subsamp - row indices of the desired sub-sample; defaults to the full sample

regf2<- function(formula,subsamp=NULL){
  if(is.null(subsamp)){subsamp=1:length(datk$wrk);W.m=W}else{
    subsamp=subsamp[which(apply(W.raw[subsamp,subsamp],1,sum)>0)] #sift out isolated observations
    W.m=W.raw[subsamp,subsamp]
    W.m = W.m/apply(W.m,1,sum)
  }
  Model.f<- g2sls(formula=formula, data = datk[subsamp,], W.m =  W.m)
  Model.f
}



regSARAR<- function(formula,subsamp=NULL){
  if(is.null(subsamp)){subsamp=1:length(datk$wrk);W.m=W}else{
    subsamp=subsamp[which(apply(W.raw[subsamp,subsamp],1,sum)>0)] #sift out isolated observations
    W.m=W.raw[subsamp,subsamp]
    W.m = W.m/apply(W.m,1,sum)
  }
 # Model.f<- g2sls(formula=formula, data = datk[subsamp,], W.m =  W.m)
  
  Model.f <- gstsls(formula=formula,data = datk[subsamp,],spdep::mat2listw(W.m),robust = TRUE)
  Model.e <- g2sls(formula=formula,data = datk[subsamp,],W.m=W.m,
                   Residuals=Model.f$residuals)
  
  fun=function(rho){gn = rep(NA,2); Gn = matrix(NA,2,2)
  WU=W.m%*%c(Model.e$residuals); WWU=W.m%*%c(WU)
  gn[1]=mean(Model.e$residuals^2); gn[2]=mean(WU^2)
  Gn[1,1]=2*mean(Model.e$residuals*WU); Gn[1,2]=-mean(WU^2)
  Gn[2,1]=2*mean(WU*WWU); Gn[2,2]=-mean(WWU^2)
  dv = gn - Gn%*%c(rho,rho^2)
  sum(dv^2)
  }
  opt.obj=optimise(fun,c(-1,1))
  Model.e$lambda=opt.obj$minimum
  return(Model.e)
}
