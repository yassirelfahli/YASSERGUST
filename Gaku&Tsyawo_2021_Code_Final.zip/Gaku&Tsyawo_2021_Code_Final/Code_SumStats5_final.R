# Summary statistics
library(dplyr)

Covariates = c("wrk","pv2","rural1","emp","sinsch","s1q5y",
"female","hnoeduc","hprim","hmid","hpmid","hwrk","rlh","hhsize","mih","fih","chr",
"mos","trd")

# Summarize total
sum_stat = datk %>%
  summarise_if(is.numeric, mean, na.rm = TRUE)
sum_stat_sd = datk %>%
  summarise_if(is.numeric, sd, na.rm = TRUE)

out1 = round(t(sum_stat),3)
out1_sd=round(t(sum_stat_sd),3)

# Summarize by gender
sum_stat_sex = datk %>%
  group_by(female) %>%
  summarise_if(is.numeric, mean, na.rm = TRUE)
sum_stat_sex_sd = datk %>%
  group_by(female) %>%
  summarise_if(is.numeric, sd, na.rm = TRUE)

# Male and female
out2 = round(t(sum_stat_sex),3)
dim(out2)
out2_sd = round(t(sum_stat_sex_sd),3)

# Summarize by ecological zone
sum_stat_eco = datk %>%
  group_by(EcZone) %>%
  summarise_if(is.numeric, mean, na.rm = TRUE)
sum_stat_eco_sd = datk %>%
  group_by(EcZone) %>%
  summarise_if(is.numeric, sd, na.rm = TRUE)

# Coastal, Forest, Savannah
out3 = round(t(sum_stat_eco[,-1]),3)
dim(out3)
out3_sd = round(t(sum_stat_eco_sd[,-1]),3)


# Summarize by location
sum_stat_loc = datk %>%
  group_by(rural1) %>%
  summarise_if(is.numeric, mean, na.rm = TRUE)
sum_stat_loc_sd = datk %>%
  group_by(rural1) %>%
  summarise_if(is.numeric, sd, na.rm = TRUE)

# Rural, Urban
out4 = round(t(sum_stat_loc),3)
dim(out4)
out4_sd = round(t(sum_stat_loc_sd),3)

# Combine summary statistics
out_all = cbind(out1[Covariates,],out3[Covariates,],out2[Covariates,],out4[Covariates,])

out_all_sd = cbind(out1_sd[Covariates,],out3_sd[Covariates,],out2_sd[Covariates,],out4_sd[Covariates,])

colnames(out_all) = c("Total",
                      "Coastal","Forest","Savannah",
                      "Male","Female",
                      "Urban","Rural")
colnames(out_all_sd)=colnames(out_all)
out_all
out_all_sd
write.csv(out_all, "SumStatFinal.csv")
write.csv(out_all, "SumStat_sd_Final.csv")

#=================================================================================>
# Age range in dataset
summary(datk$s1q5y)
# Min. 1st Qu.  Median    Mean 3rd Qu.    Max. 
# 5.00    8.00   11.00   10.67   14.00   17.00











