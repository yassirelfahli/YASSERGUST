#rm(list = ls())
setwd(dirname(rstudioapi::getActiveDocumentContext()$path)) 
#set directory to source file
list.files()
library(spatialreg)
library(spdep)
#sourcing files for data and functions - takes a bit of time
source("Create_Dat3_final.R")
source("Funciones.R")
#----------------------------------------------------------------------------------
names(datk)
#-------------------------------------------
# Function to run sub-samples
# Arguments:  var.sub - the discrete variable along which sub-samples are created
#             formula - the formula to run on the sub-sample; defaults to fml.1
# This function only prints out output

ssregs=function(var.sub,formula=fml.1){
  u.var = unique(var.sub)
  for (l in 1:length(u.var)) {
    cat("Sub-sample is ",u.var[l]," \n")
    id = which(var.sub==u.var[l])
    Modl = regSARAR(formula = formula,subsamp = id) #use sub-sample
    summary.g2sls(Modl,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
    cat(rep("=",45)); cat("\n")
  }#end for l
}

#=====================================================================================>
#********* Begin Printing out output to file
Out_log <- file("Out_log3_final_SARAR.txt") # File name of output log

sink(Out_log, append = TRUE, type = "output") # Writing console output to log file
sink(Out_log, append = TRUE, type = "message")

cat(readChar(rstudioapi::getSourceEditorContext()$path, # Writing currently opened R script to file
             file.info(rstudioapi::getSourceEditorContext()$path)$size))
#=====================================================================================>



#----------------------------------------------------------------------------------
cat("\n")
cat("Full Sample - Results","\n")
fml.1 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)+as.factor(region)"))
Mod.1 = regSARAR(formula = fml.1) #use full sample
summary.g2sls(Mod.1,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude religious dummies
cat("\n")
cat("Full Sample - Results with religious dummies excluded","\n")
fml.2 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+as.factor(EcZone)+as.factor(region)"))
Mod.2 = regSARAR(formula = fml.2) #use full sample
summary.g2sls(Mod.2,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude household characteristics
cat("\n")
cat("Full Sample - Results with household characteristics excluded","\n")
fml.3 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+chr+mos+trd+as.factor(EcZone)+as.factor(region)"))
Mod.3 = regSARAR(formula = fml.3) #use full sample
summary.g2sls(Mod.3,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude Ecological Zone dummies
cat("\n")
cat("Full Sample - Results with Ecological Zone dummies excluded","\n")
fml.4 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(region)"))
Mod.4 = regSARAR(formula = fml.4) #use full sample
summary.g2sls(Mod.4,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude Regional dummies
cat("\n")
cat("Full Sample - Results with Regional dummies excluded","\n")
fml.5 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)"))
Mod.5 = regSARAR(formula = fml.5) #use full sample
summary.g2sls(Mod.5,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------
# Exclude age and age squared
cat("\n")
cat("Full Sample - Results with age variables excluded","\n")
fml.8 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)+as.factor(region)"))
Mod.8 = regSARAR(formula = fml.8) #use full sample
summary.g2sls(Mod.8,marg_effect=FALSE,bet.id=3,L=1000,cl=5)
cat(rep("=",45)); cat("\n")
#----------------------------------------------------------------------------------



#----------------------------------------------------------------------------------
# Formulae for sub-groups to study - Ecological Zones, Sex, Rural/Urban, Regions
fml.EcZone = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(region)"))
fml.sex = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)+as.factor(region)"))
fml.rural = as.formula(paste("wrk~pv2+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)+as.factor(region)"))
#for regions with more than one ecological zone
fml.region1 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd+as.factor(EcZone)"))
#drop ecological zone dummies for regions with one ecological zone
fml.region2 = as.formula(paste("wrk~pv2+rural1+emp+sinsch+s1q5y+I(s1q5y^2)+female+hprim+hmid+hpmid+hwrk+rlh+hhsize+mih+fih+chr+mos+trd"))


# ------------- Ecological Zones ------------- 
cat("\n")
cat("Sub Sample Results by Ecological Zone","\n")
ssregs(var.sub=datk$EcZone,formula=fml.EcZone)

# ------------- Sex ------------- 
cat("\n")
cat("Sub Sample Results by Sex","\n")
ssregs(var.sub=datk$sex,formula=fml.sex)

# ------------- Rural/Urban ------------- 
cat("\n")
cat("Sub Sample Results by Rural/Urban (1/0)","\n")
ssregs(var.sub=datk$rural1,formula=fml.rural)
#----------------------------------------------------------------------------------



#----------------------------------------------------------------------------------
# ------------- Regions ------------- 
cat("\n")
cat("Sub Sample Results by Region","\n")
u.varR=unique(datk$region)

for(r in 1:length(unique(datk$region))){
  cat("Region Name: ",u.varR[r],"\n")
  cat("Ecological Zones in the ",u.varR[r]," Region are ")
  u.EZ=unique(datk$EcZone[which(datk$region==u.varR[r])])
  print(u.EZ); cat("\n")
  id = which(datk$region==u.varR[r])
  # avoid Ecological Zone dummies if there is only one Ecological in Region
  if(length(u.EZ)>1){
  Modl = regSARAR(formula = fml.region1,subsamp = id) 
  }else{
  Modl = regSARAR(formula = fml.region2,subsamp = id)
  }#end if/else
  print(summary.g2sls(Modl,marg_effect=FALSE,bet.id=3,L=1000,cl=5))
  cat(rep("=",45)); cat("\n")
}
#----------------------------------------------------------------------------------
# ------------- Region & Ecological Zone ------------- 
#u.eZ=unique(datk$EcZone)
for(r in 1:length(u.varR)){
  u.eZ=unique(datk$EcZone[which(datk$region==u.varR[r])])
  if(length(u.eZ)>1){#avoids redundancy where there is only one Ecological Zone in the Region
  for(e in 1:length(u.eZ)){
    cat("Region Name: ",u.varR[r]," & Ecological Zone: ",u.eZ[e],"\n")

    id = which(datk$region==u.varR[r] & datk$EcZone==u.eZ[e])
    Modl = regSARAR(formula = fml.region2,subsamp = id)
    print(summary.g2sls(Modl,marg_effect=FALSE,bet.id=3,L=1000,cl=5))
    cat(rep("=",45)); cat("\n")
  }#end for e
  }#end if
}#end for r
#----------------------------------------------------------------------------------

# List of Regions and their Ecological Zones
u.varR=unique(datk$region)

for(r in 1:length(u.varR)){
  cat("Region Name: ",u.varR[r],"\n")
  u.eZ=unique(datk$EcZone[which(datk$region==u.varR[r])])
  cat("Ecological Zones: ",u.eZ,"\n")
}


# Region Name:  Western 
# Ecological Zones:  Coastal Forest 
# Region Name:  Central 
# Ecological Zones:  Coastal Forest 
# Region Name:  Greater Accra 
# Ecological Zones:  Coastal 
# Region Name:  Volta 
# Ecological Zones:  Coastal Forest Savannah 
# Region Name:  Eastern 
# Ecological Zones:  Forest 
# Region Name:  Ashanti 
# Ecological Zones:  Forest 
# Region Name:  Brong Ahafo 
# Ecological Zones:  Savannah Forest 
# Region Name:  Northern 
# Ecological Zones:  Savannah 
# Region Name:  Upper East 
# Ecological Zones:  Savannah 
# Region Name:  Upper West 
# Ecological Zones:  Savannah

#=====================================================================================>
# Closing Log File
closeAllConnections() # Close connection to log file
#=====================================================================================>
